const { ethers } = require("hardhat");
const fs = require("fs");
require("dotenv").config();

async function main() {
    console.log("🚀 Starting TokenStaking deployment...");

    // 1. Get RewardToken address
    // We can get it from .env or hardcode it if we know it
    // In this project, it's already deployed at:
    const REWARD_TOKEN_ADDRESS = "0xCfA9a3844aD661F9A63Bb446A4b2178c831291cf";

    if (!REWARD_TOKEN_ADDRESS) {
        console.error("❌ REWARD_TOKEN_ADDRESS not found!");
        process.exit(1);
    }

    console.log("📍 RewardToken Address:", REWARD_TOKEN_ADDRESS);

    // 2. Deploy TokenStaking
    const TokenStaking = await ethers.getContractFactory("TokenStaking");
    const tokenStaking = await TokenStaking.deploy(REWARD_TOKEN_ADDRESS);

    await tokenStaking.waitForDeployment();
    const stakingAddress = await tokenStaking.getAddress();

    console.log("✅ TokenStaking deployed to:", stakingAddress);

    // 3. Output for user
    console.log("\n----------------------------------------------------");
    console.log(`STAKING_CONTRACT_ADDRESS="${stakingAddress}"`);
    console.log("----------------------------------------------------");
    console.log("⚠️  Please update services/web3.ts with this address!");
    console.log("⚠️  Don't forget to fund the contract with FRM tokens for rewards!");

    // Optional: Verify on Polygonscan
    // await hre.run("verify:verify", {
    //   address: stakingAddress,
    //   constructorArguments: [REWARD_TOKEN_ADDRESS],
    // });
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
