const { ethers } = require('hardhat');
const cron = require('node-cron');
require('dotenv').config();

// Import ABI
const SpeedNFT = require('../artifacts/contracts/SpeedNFT.sol/SpeedNFT.json');

const SPEED_NFT_ADDRESS = process.env.SPEED_NFT_ADDRESS || "0x28067769a344De30EdeCbD895bc8fEDAFBeEe8C5";
const PRIVATE_KEY = process.env.PRIVATE_KEY;
const RPC_URL = process.env.RPC_URL || "https://polygon-rpc.com";

async function main() {
    console.log("🤖 Auto-Withdraw Bot Started!");
    console.log("⏰ Will check contract balance every 2 hours");
    console.log("📍 Contract:", SPEED_NFT_ADDRESS);
    console.log("---");

    if (!PRIVATE_KEY) {
        console.error("❌ PRIVATE_KEY not set in .env file");
        process.exit(1);
    }

    // Setup provider and wallet
    const provider = new ethers.JsonRpcProvider(RPC_URL);
    const wallet = new ethers.Wallet(PRIVATE_KEY, provider);
    const contract = new ethers.Contract(SPEED_NFT_ADDRESS, SpeedNFT.abi, wallet);

    console.log("👤 Wallet:", wallet.address);

    async function checkAndWithdraw() {
        try {
            console.log(`\n[${new Date().toLocaleString()}] Checking contract balance...`);

            // Get contract balance
            const balance = await provider.getBalance(SPEED_NFT_ADDRESS);
            const balanceInPOL = ethers.formatEther(balance);

            console.log(`💰 Contract Balance: ${balanceInPOL} POL`);

            if (parseFloat(balanceInPOL) > 0) {
                console.log("🚀 Initiating withdrawal...");

                const tx = await contract.withdraw();
                console.log("📤 Transaction sent:", tx.hash);

                const receipt = await tx.wait();
                console.log("✅ Withdrawal successful!");
                console.log("⛽ Gas used:", receipt.gasUsed.toString());

                // Get new balance
                const newBalance = await provider.getBalance(SPEED_NFT_ADDRESS);
                console.log("💰 New contract balance:", ethers.formatEther(newBalance), "POL");
            } else {
                console.log("ℹ️  No funds to withdraw");
            }
        } catch (error) {
            console.error("❌ Error during withdrawal:", error.message);
            if (error.reason) console.error("Reason:", error.reason);
        }
    }

    // Run immediately on start
    console.log("\n🔍 Running initial check...");
    await checkAndWithdraw();

    // Schedule to run every 2 hours (0 */2 * * *)
    cron.schedule('0 */2 * * *', async () => {
        await checkAndWithdraw();
    });

    console.log("\n✅ Cron job scheduled! Running every 2 hours at minute 0");
    console.log("Press Ctrl+C to stop");
}

main().catch((error) => {
    console.error("Fatal error:", error);
    process.exit(1);
});
