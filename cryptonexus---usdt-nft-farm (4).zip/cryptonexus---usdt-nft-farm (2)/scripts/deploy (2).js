const hre = require("hardhat");

async function main() {
    const [deployer] = await hre.ethers.getSigners();

    console.log("Deploying contracts with the account:", deployer.address);

    // 1. Deploy RewardToken
    const RewardToken = await hre.ethers.getContractFactory("RewardToken");
    const rewardToken = await RewardToken.deploy();
    await rewardToken.waitForDeployment();
    const rewardTokenAddress = await rewardToken.getAddress();
    console.log("RewardToken deployed to:", rewardTokenAddress);

    // 2. Deploy SpeedNFT
    const SpeedNFT = await hre.ethers.getContractFactory("SpeedNFT");
    const nftCollection = await SpeedNFT.deploy();
    await nftCollection.waitForDeployment();
    const nftCollectionAddress = await nftCollection.getAddress();
    console.log("SpeedNFT deployed to:", nftCollectionAddress);

    // 3. Deploy NFTFarm
    const NFTFarm = await hre.ethers.getContractFactory("NFTFarm");
    const nftFarm = await NFTFarm.deploy(rewardTokenAddress, nftCollectionAddress);
    await nftFarm.waitForDeployment();
    const nftFarmAddress = await nftFarm.getAddress();
    console.log("NFTFarm deployed to:", nftFarmAddress);

    // 4. Transfer ownership of RewardToken to NFTFarm
    // This is crucial so the Farm can mint rewards
    await rewardToken.transferOwnership(nftFarmAddress);
    console.log("Transferred RewardToken ownership to NFTFarm");

    console.log("Deployment complete!");
    console.log("----------------------------------");
    console.log("RewardToken:", rewardTokenAddress);
    console.log("SpeedNFT:", nftCollectionAddress);
    console.log("NFTFarm:", nftFarmAddress);
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
