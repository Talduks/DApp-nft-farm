const hre = require("hardhat");

async function main() {
    console.log("Starting deployment...");

    const [deployer] = await hre.ethers.getSigners();
    console.log("Deploying contracts with the account:", deployer.address);

    // 1. Deploy DAppToken (with AccessControl)
    const DAppToken = await hre.ethers.getContractFactory("DAppToken");
    const rewardToken = await DAppToken.deploy();
    await rewardToken.waitForDeployment();
    const rewardTokenAddress = await rewardToken.getAddress();
    console.log("DAppToken deployed to:", rewardTokenAddress);

    // 2. Deploy Speed NFT
    const SpeedNFT = await hre.ethers.getContractFactory("SpeedNFT");
    const nftCollection = await SpeedNFT.deploy();
    await nftCollection.waitForDeployment();
    const nftCollectionAddress = await nftCollection.getAddress();
    console.log("SpeedNFT deployed to:", nftCollectionAddress);

    // 3. Deploy NFTFarm
    const NFTFarm = await hre.ethers.getContractFactory("NFTFarm");
    const farm = await NFTFarm.deploy(rewardTokenAddress, nftCollectionAddress);
    await farm.waitForDeployment();
    const farmAddress = await farm.getAddress();
    console.log("NFTFarm deployed to:", farmAddress);

    // 4. Deploy TokenStaking
    const TokenStaking = await hre.ethers.getContractFactory("TokenStaking");
    const staking = await TokenStaking.deploy(rewardTokenAddress);
    await staking.waitForDeployment();
    const stakingAddress = await staking.getAddress();
    console.log("TokenStaking deployed to:", stakingAddress);

    // 5. Setup Permissions
    console.log("Setting up permissions...");

    // Grant MINTER_ROLE to NFTFarm
    const MINTER_ROLE = await rewardToken.MINTER_ROLE();
    await rewardToken.grantRole(MINTER_ROLE, farmAddress);
    console.log("Granted MINTER_ROLE to NFTFarm");

    // Optional: Grant MINTER_ROLE to TokenStaking if we want it to mint rewards directly
    // For now, we will stick to the funded pool model or mint initial supply to it.
    // Let's mint some initial supply to the deployer to fund the Staking contract later manually or via script
    // await rewardToken.mint(deployer.address, hre.ethers.parseEther("1000000")); 

    // 6. Mint test NFTs
    console.log("Minting test NFTs...");
    await nftCollection.mint(deployer.address, 10);
    await nftCollection.mint(deployer.address, 20);
    await nftCollection.mint(deployer.address, 50);
    console.log("Minted 3 NFTs to deployer.");

    console.log("\nDeployment Complete!");
    console.log("----------------------------------------------------");
    console.log(`SPEED_NFT_ADDRESS="${nftCollectionAddress}"`);
    console.log(`REWARD_TOKEN_ADDRESS="${rewardTokenAddress}"`);
    console.log(`FARM_CONTRACT_ADDRESS="${farmAddress}"`);
    console.log(`STAKING_CONTRACT_ADDRESS="${stakingAddress}"`);
    console.log("----------------------------------------------------");
    console.log("Please update these addresses in services/web3.ts");
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
