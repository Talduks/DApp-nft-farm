const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("NFTFarm", function () {
    let RewardToken, SpeedNFT, NFTFarm;
    let rewardToken, nftCollection, nftFarm;
    let owner, addr1;

    beforeEach(async function () {
        [owner, addr1] = await ethers.getSigners();

        RewardToken = await ethers.getContractFactory("RewardToken");
        rewardToken = await RewardToken.deploy();

        SpeedNFT = await ethers.getContractFactory("SpeedNFT");
        nftCollection = await SpeedNFT.deploy();

        NFTFarm = await ethers.getContractFactory("NFTFarm");
        nftFarm = await NFTFarm.deploy(await rewardToken.getAddress(), await nftCollection.getAddress());

        // Transfer ownership of RewardToken to Farm so it can mint
        await rewardToken.transferOwnership(await nftFarm.getAddress());
    });

    it("Should mint NFT with speed and stake it", async function () {
        // Mint NFT with speed 10 to addr1
        await nftCollection.mint(addr1.address, 10);
        expect(await nftCollection.ownerOf(0)).to.equal(addr1.address);
        expect(await nftCollection.getFarmingSpeed(0)).to.equal(10);

        // Approve and Stake
        await nftCollection.connect(addr1).approve(await nftFarm.getAddress(), 0);
        await nftFarm.connect(addr1).stake(0);

        expect(await nftCollection.ownerOf(0)).to.equal(await nftFarm.getAddress());

        // Check stake info
        const stake = await nftFarm.stakes(0);
        expect(stake.owner).to.equal(addr1.address);
    });

    it("Should accumulate rewards over time", async function () {
        await nftCollection.mint(addr1.address, 10);
        await nftCollection.connect(addr1).approve(await nftFarm.getAddress(), 0);
        await nftFarm.connect(addr1).stake(0);

        // Increase time by 100 seconds
        await ethers.provider.send("evm_increaseTime", [100]);
        await ethers.provider.send("evm_mine");

        // Calculate reward: 100s * 10 speed * 1e14 rate = 1e17
        const reward = await nftFarm.calculateReward(0);
        // Allow for small time discrepancies
        expect(reward).to.be.closeTo(ethers.parseUnits("0.1", 18), ethers.parseUnits("0.001", 18)); // 0.1 tokens
    });

    it("Should claim rewards and withdraw", async function () {
        await nftCollection.mint(addr1.address, 10);
        await nftCollection.connect(addr1).approve(await nftFarm.getAddress(), 0);
        await nftFarm.connect(addr1).stake(0);

        await ethers.provider.send("evm_increaseTime", [100]);
        await ethers.provider.send("evm_mine");

        await nftFarm.connect(addr1).withdraw(0);

        expect(await nftCollection.ownerOf(0)).to.equal(addr1.address);
        expect(await rewardToken.balanceOf(addr1.address)).to.be.gt(0);
    });
});
