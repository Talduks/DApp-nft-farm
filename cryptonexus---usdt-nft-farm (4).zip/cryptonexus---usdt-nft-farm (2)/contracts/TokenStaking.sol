// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

contract TokenStaking is Ownable, ReentrancyGuard {
    IERC20 public rewardToken;

    // APY: 22% anual
    uint256 public constant APY = 22;
    uint256 public constant SECONDS_PER_YEAR = 365 days;

    struct StakeInfo {
        uint256 amount;
        uint256 startTime;
        uint256 lockPeriodMonths; // 3, 6, or 12
        uint256 endTime;
        bool withdrawn;
    }

    // user => stakeId => StakeInfo
    mapping(address => mapping(uint256 => StakeInfo)) public stakes;
    mapping(address => uint256) public stakeCount;

    event Staked(address indexed user, uint256 stakeId, uint256 amount, uint256 lockMonths);
    event Unstaked(address indexed user, uint256 stakeId, uint256 principal, uint256 reward);

    constructor(address _rewardToken) Ownable(msg.sender) {
        rewardToken = IERC20(_rewardToken);
    }

    /**
     * @dev Stake tokens with a lock period
     * @param amount Amount of tokens to stake
     * @param lockMonths Lock period in months (3, 6, or 12)
     */
    function stake(uint256 amount, uint8 lockMonths) external nonReentrant {
        require(amount > 0, "Amount must be > 0");
        require(lockMonths == 3 || lockMonths == 6 || lockMonths == 12, "Invalid lock period");
        
        // Transfer tokens from user to contract
        require(rewardToken.transferFrom(msg.sender, address(this), amount), "Transfer failed");

        uint256 stakeId = stakeCount[msg.sender];
        uint256 lockDuration = uint256(lockMonths) * 30 days;
        
        stakes[msg.sender][stakeId] = StakeInfo({
            amount: amount,
            startTime: block.timestamp,
            lockPeriodMonths: lockMonths,
            endTime: block.timestamp + lockDuration,
            withdrawn: false
        });

        stakeCount[msg.sender]++;
        
        emit Staked(msg.sender, stakeId, amount, lockMonths);
    }

    /**
     * @dev Calculate reward for a specific stake
     * Formula: principal * (APY% * months / 12)
     */
    function calculateReward(address user, uint256 stakeId) public view returns (uint256) {
        StakeInfo memory stakeInfo = stakes[user][stakeId];
        
        if (stakeInfo.amount == 0 || stakeInfo.withdrawn) {
            return 0;
        }

        // Reward = principal * (22% * months / 12)
        // = principal * 22 * months / 1200
        uint256 reward = (stakeInfo.amount * APY * stakeInfo.lockPeriodMonths) / 1200;
        
        return reward;
    }

    /**
     * @dev Unstake tokens and claim rewards
     * Can only be called after lock period ends
     */
    function unstake(uint256 stakeId) external nonReentrant {
        StakeInfo storage stakeInfo = stakes[msg.sender][stakeId];
        
        require(stakeInfo.amount > 0, "No stake found");
        require(!stakeInfo.withdrawn, "Already withdrawn");
        require(block.timestamp >= stakeInfo.endTime, "Lock period not ended");

        uint256 principal = stakeInfo.amount;
        uint256 reward = calculateReward(msg.sender, stakeId);
        uint256 total = principal + reward;

        stakeInfo.withdrawn = true;

        // Transfer principal + rewards
        require(rewardToken.transfer(msg.sender, total), "Transfer failed");

        emit Unstaked(msg.sender, stakeId, principal, reward);
    }

    /**
     * @dev Get all active stakes for a user
     */
    function getActiveStakes(address user) external view returns (
        uint256[] memory stakeIds,
        uint256[] memory amounts,
        uint256[] memory startTimes,
        uint256[] memory endTimes,
        uint256[] memory lockMonths,
        uint256[] memory rewards
    ) {
        uint256 count = stakeCount[user];
        uint256 activeCount = 0;

        // Count active stakes
        for (uint256 i = 0; i < count; i++) {
            if (!stakes[user][i].withdrawn && stakes[user][i].amount > 0) {
                activeCount++;
            }
        }

        // Allocate arrays
        stakeIds = new uint256[](activeCount);
        amounts = new uint256[](activeCount);
        startTimes = new uint256[](activeCount);
        endTimes = new uint256[](activeCount);
        lockMonths = new uint256[](activeCount);
        rewards = new uint256[](activeCount);

        // Fill arrays
        uint256 index = 0;
        for (uint256 i = 0; i < count; i++) {
            StakeInfo memory stakeInfo = stakes[user][i];
            if (!stakeInfo.withdrawn && stakeInfo.amount > 0) {
                stakeIds[index] = i;
                amounts[index] = stakeInfo.amount;
                startTimes[index] = stakeInfo.startTime;
                endTimes[index] = stakeInfo.endTime;
                lockMonths[index] = stakeInfo.lockPeriodMonths;
                rewards[index] = calculateReward(user, i);
                index++;
            }
        }

        return (stakeIds, amounts, startTimes, endTimes, lockMonths, rewards);
    }

    /**
     * @dev Check if stake can be withdrawn
     */
    function canUnstake(address user, uint256 stakeId) external view returns (bool) {
        StakeInfo memory stakeInfo = stakes[user][stakeId];
        return !stakeInfo.withdrawn && 
               stakeInfo.amount > 0 && 
               block.timestamp >= stakeInfo.endTime;
    }

    /**
     * @dev Get time remaining until unlock
     */
    function getTimeRemaining(address user, uint256 stakeId) external view returns (uint256) {
        StakeInfo memory stakeInfo = stakes[user][stakeId];
        
        if (block.timestamp >= stakeInfo.endTime) {
            return 0;
        }
        
        return stakeInfo.endTime - block.timestamp;
    }

    /**
     * @dev Owner can fund the contract with rewards
     */
    function fundRewards(uint256 amount) external onlyOwner {
        require(rewardToken.transferFrom(msg.sender, address(this), amount), "Transfer failed");
    }

    /**
     * @dev Emergency withdraw for owner (only unused funds)
     */
    function emergencyWithdraw(uint256 amount) external onlyOwner {
        require(rewardToken.transfer(owner(), amount), "Transfer failed");
    }
}
