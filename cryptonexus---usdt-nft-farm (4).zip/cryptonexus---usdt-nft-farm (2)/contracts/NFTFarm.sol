// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC721/IERC721Receiver.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "./DAppToken.sol";
import "./SpeedNFT.sol";

contract NFTFarm is IERC721Receiver, Ownable {
    DAppToken public rewardToken;
    SpeedNFT public nftCollection;

    struct Stake {
        address owner;
        uint256 timestamp;
    }

    // tokenId => Stake
    mapping(uint256 => Stake) public stakes;
    
    // User => Array of Staked Token IDs (For frontend display)
    mapping(address => uint256[]) public userStakedTokens;

    // Tokens per speed unit per second
    uint256 public rewardRate = 1e14; // Example rate

    event Staked(address indexed user, uint256 tokenId);
    event Withdrawn(address indexed user, uint256 tokenId);
    event RewardClaimed(address indexed user, uint256 reward);

    constructor(address _rewardToken, address _nftCollection) Ownable(msg.sender) {
        rewardToken = DAppToken(_rewardToken);
        nftCollection = SpeedNFT(_nftCollection);
    }

    function stake(uint256 tokenId) external {
        nftCollection.safeTransferFrom(msg.sender, address(this), tokenId);
        stakes[tokenId] = Stake(msg.sender, block.timestamp);
        userStakedTokens[msg.sender].push(tokenId);
        emit Staked(msg.sender, tokenId);
    }

    function calculateReward(uint256 tokenId) public view returns (uint256) {
        Stake memory stakedItem = stakes[tokenId];
        if (stakedItem.owner == address(0)) return 0;

        uint256 timeElapsed = block.timestamp - stakedItem.timestamp;
        
        // Cap at 1 year to prevent overflow
        uint256 maxTime = 365 days;
        if (timeElapsed > maxTime) {
            timeElapsed = maxTime;
        }
        
        uint256 speed = nftCollection.getFarmingSpeed(tokenId);
        
        return timeElapsed * speed * rewardRate;
    }

    function claimReward(uint256 tokenId) public {
        Stake storage stakedItem = stakes[tokenId];
        require(stakedItem.owner == msg.sender, "Not the owner");

        uint256 reward = calculateReward(tokenId);
        require(reward > 0, "No reward to claim");

        stakedItem.timestamp = block.timestamp; // Reset timestamp
        rewardToken.mint(msg.sender, reward);
        
        emit RewardClaimed(msg.sender, reward);
    }

    function withdraw(uint256 tokenId) external {
        Stake memory stakedItem = stakes[tokenId];
        require(stakedItem.owner == msg.sender, "Not the owner");

        // Claim pending rewards first
        uint256 reward = calculateReward(tokenId);
        if (reward > 0) {
            rewardToken.mint(msg.sender, reward);
            emit RewardClaimed(msg.sender, reward);
        }

        delete stakes[tokenId];
        removeTokenFromUser(msg.sender, tokenId);
        
        nftCollection.safeTransferFrom(address(this), msg.sender, tokenId);
        
        emit Withdrawn(msg.sender, tokenId);
    }

    function getStakedTokens(address user) external view returns (uint256[] memory) {
        return userStakedTokens[user];
    }
    
    function getTotalClaimable(address user) external view returns (uint256) {
        uint256 total = 0;
        uint256[] memory tokens = userStakedTokens[user];
        for(uint256 i = 0; i < tokens.length; i++) {
            total += calculateReward(tokens[i]);
        }
        return total;
    }

    function removeTokenFromUser(address user, uint256 tokenId) internal {
        uint256[] storage tokens = userStakedTokens[user];
        for (uint256 i = 0; i < tokens.length; i++) {
            if (tokens[i] == tokenId) {
                tokens[i] = tokens[tokens.length - 1];
                tokens.pop();
                break;
            }
        }
    }

    function onERC721Received(
        address,
        address,
        uint256,
        bytes calldata
    ) external pure override returns (bytes4) {
        return IERC721Receiver.onERC721Received.selector;
    }

    function setRewardRate(uint256 _rate) external onlyOwner {
        rewardRate = _rate;
    }
}
