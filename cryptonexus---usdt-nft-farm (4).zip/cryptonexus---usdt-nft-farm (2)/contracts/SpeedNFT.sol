// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import "@openzeppelin/contracts/token/ERC721/extensions/ERC721Enumerable.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract SpeedNFT is ERC721, ERC721Enumerable, Ownable {
    uint256 private _nextTokenId;
    mapping(uint256 => uint256) public farmingSpeeds;
    
    uint256 public mintPrice = 1 ether; // 1 POL

    event NftMinted(address indexed user, uint256 tokenId, uint256 speed);

    constructor() ERC721("Speed NFT", "SPDNFT") Ownable(msg.sender) {}

    // Owner can still mint for free/specific speed if needed
    function mint(address to, uint256 speed) external onlyOwner {
        _mintWithSpeed(to, speed);
    }

    // Public mint with payment and random speed
    function publicMint() external payable {
        require(msg.value >= mintPrice, "Insufficient funds");
        
        // Refund excess payment
        uint256 excess = msg.value - mintPrice;
        if (excess > 0) {
            (bool refundSuccess, ) = payable(msg.sender).call{value: excess}("");
            require(refundSuccess, "Refund failed");
        }
        
        // Pseudo-random speed between 10 and 100
        // NOTE: This is predictable! For production, consider using Chainlink VRF
        uint256 randomSpeed = (uint256(keccak256(abi.encodePacked(block.timestamp, msg.sender, _nextTokenId))) % 91) + 10;
        
        _mintWithSpeed(msg.sender, randomSpeed);
    }

    function _mintWithSpeed(address to, uint256 speed) internal {
        uint256 tokenId = _nextTokenId++;
        _safeMint(to, tokenId);
        farmingSpeeds[tokenId] = speed;
        emit NftMinted(to, tokenId, speed);
    }

    function getFarmingSpeed(uint256 tokenId) external view returns (uint256) {
        return farmingSpeeds[tokenId];
    }

    function setMintPrice(uint256 _price) external onlyOwner {
        require(_price > 0, "Price must be greater than 0");
        mintPrice = _price;
    }

    function withdraw() external onlyOwner {
        uint256 balance = address(this).balance;
        require(balance > 0, "No funds to withdraw");
        
        (bool success, ) = payable(owner()).call{value: balance}("");
        require(success, "Transfer failed");
    }

    // Generate SVG image on-chain
    function generateSVG(uint256 tokenId) internal view returns (string memory) {
        uint256 speed = farmingSpeeds[tokenId];
        
        // Color based on speed: red (slow) to green (fast)
        string memory color = speed < 40 ? "#ef4444" : speed < 70 ? "#f59e0b" : "#22c55e";
        
        return string(abi.encodePacked(
            '<svg width="350" height="350" xmlns="http://www.w3.org/2000/svg">',
            '<defs>',
            '<linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">',
            '<stop offset="0%" style="stop-color:#1e293b"/><stop offset="100%" style="stop-color:#0f172a"/>',
            '</linearGradient>',
            '<filter id="glow"><feGaussianBlur stdDeviation="4" result="coloredBlur"/>',
            '<feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>',
            '</defs>',
            '<rect width="350" height="350" fill="url(#bg)"/>',
            '<g transform="translate(175, 175)" filter="url(#glow)">',
            '<circle r="80" fill="none" stroke="', color, '" stroke-width="3" opacity="0.3"/>',
            '<path d="M-40,-40 L-30,-50 L-50,-30 Z M40,-40 L50,-30 L30,-50 Z M40,40 L30,50 L50,30 Z M-40,40 L-50,30 L-30,50 Z" fill="', color, '"/>',
            '<circle r="60" fill="none" stroke="', color, '" stroke-width="8"/>',
            '<circle r="20" fill="', color, '"/>',
            '<text x="0" y="120" text-anchor="middle" font-size="24" font-weight="bold" fill="white">#', toString(tokenId), '</text>',
            '<text x="0" y="145" text-anchor="middle" font-size="18" fill="', color, '">SPEED: ', toString(speed), '</text>',
            '</g></svg>'
        ));
    }

    // Override tokenURI to return metadata
    function tokenURI(uint256 tokenId) public view virtual override returns (string memory) {
        require(ownerOf(tokenId) != address(0), "Token does not exist");
        
        string memory svg = generateSVG(tokenId);
        string memory json = Base64.encode(bytes(string(abi.encodePacked(
            '{"name": "Speed NFT #', toString(tokenId), 
            '", "description": "A farming NFT with speed ', toString(farmingSpeeds[tokenId]),
            '. Stake to earn rewards!", "image": "data:image/svg+xml;base64,',
            Base64.encode(bytes(svg)),
            '", "attributes": [{"trait_type": "Speed", "value": ', toString(farmingSpeeds[tokenId]), '}]}'
        ))));
        
        return string(abi.encodePacked('data:application/json;base64,', json));
    }

    // Helper function to convert uint to string
    function toString(uint256 value) internal pure returns (string memory) {
        if (value == 0) return "0";
        uint256 temp = value;
        uint256 digits;
        while (temp != 0) {
            digits++;
            temp /= 10;
        }
        bytes memory buffer = new bytes(digits);
        while (value != 0) {
            digits -= 1;
            buffer[digits] = bytes1(uint8(48 + uint256(value % 10)));
            value /= 10;
        }
        return string(buffer);
    }

    // The following functions are overrides required by Solidity.

    function _update(address to, uint256 tokenId, address auth)
        internal
        override(ERC721, ERC721Enumerable)
        returns (address)
    {
        return super._update(to, tokenId, auth);
    }

    function _increaseBalance(address account, uint128 value)
        internal
        override(ERC721, ERC721Enumerable)
    {
        super._increaseBalance(account, value);
    }

    function supportsInterface(bytes4 interfaceId)
        public
        view
        override(ERC721, ERC721Enumerable)
        returns (bool)
    {
        return super.supportsInterface(interfaceId);
    }
}

// Base64 encoding library
library Base64 {
    bytes internal constant TABLE = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    function encode(bytes memory data) internal pure returns (string memory) {
        uint256 len = data.length;
        if (len == 0) return "";

        uint256 encodedLen = 4 * ((len + 2) / 3);
        bytes memory result = new bytes(encodedLen + 32);
        bytes memory table = TABLE;

        assembly {
            let tablePtr := add(table, 1)
            let resultPtr := add(result, 32)
            for { let i := 0 } lt(i, len) { } {
                i := add(i, 3)
                let input := and(mload(add(data, i)), 0xffffff)
                let out := mload(add(tablePtr, and(shr(18, input), 0x3F)))
                out := shl(8, out)
                out := add(out, and(mload(add(tablePtr, and(shr(12, input), 0x3F))), 0xFF))
                out := shl(8, out)
                out := add(out, and(mload(add(tablePtr, and(shr(6, input), 0x3F))), 0xFF))
                out := shl(8, out)
                out := add(out, and(mload(add(tablePtr, and(input, 0x3F))), 0xFF))
                out := shl(224, out)
                mstore(resultPtr, out)
                resultPtr := add(resultPtr, 4)
            }
            switch mod(len, 3)
            case 1 { mstore(sub(resultPtr, 2), shl(240, 0x3d3d)) }
            case 2 { mstore(sub(resultPtr, 1), shl(248, 0x3d)) }
            mstore(result, encodedLen)
        }
        return string(result);
    }
}
