import React, { useState, useEffect } from 'react';
import { Wallet, Sprout, Egg as EggIcon, Shield, TrendingUp, LogOut } from 'lucide-react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth } from './services/firebase';
import { logoutUser, linkWalletToUser } from './services/authService';
import Dashboard from './components/Dashboard';
import WalletConnect from './components/WalletConnect';
import MysteryEgg from './components/MysteryEgg';
import AdminPanel from './components/AdminPanel';
import TokenStaking from './components/TokenStaking';
import Auth from './components/Auth';
import { connectWallet, getFarmingData, checkWalletConnection, checkIsOwner } from './services/web3';
import ErrorBoundary from './components/ErrorBoundary';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [account, setAccount] = useState<string | null>(null);
  const [farmingData, setFarmingData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [isOwner, setIsOwner] = useState(false);
  const [currentView, setCurrentView] = useState<'dashboard' | 'egg' | 'admin' | 'staking'>('dashboard');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);

      // Auto-connect wallet if available and user is logged in
      if (currentUser) {
        const connectedAddr = await checkWalletConnection();
        if (connectedAddr) {
          setAccount(connectedAddr);
          const ownerStatus = await checkIsOwner(connectedAddr);
          setIsOwner(ownerStatus);
          // Ensure wallet is linked in Firestore
          await linkWalletToUser(currentUser.uid, connectedAddr);
        }
      }
    });
    return () => unsubscribe();
  }, []);

  const handleConnect = async () => {
    try {
      const acc = await connectWallet();
      setAccount(acc);
      const ownerStatus = await checkIsOwner(acc);
      setIsOwner(ownerStatus);

      // Link wallet to authenticated user
      if (user) {
        try {
          await linkWalletToUser(user.uid, acc);
        } catch (linkError: any) {
          console.error("Erro ao vincular carteira:", linkError);
          alert(linkError.message);
          // Optional: Disconnect wallet if link fails?
          // setAccount(null); 
          // For now, we let them stay connected but warned that it's not linked/saved if blocked.
          // But if it's banned, maybe we should disconnect.
          if (linkError.message.includes("restrição")) {
            setAccount(null);
          }
        }
      }

      setCurrentView('egg'); // Default to Egg view after connection
    } catch (error: any) {
      console.error(error);
      alert("Erro ao conectar: " + (error.message || "Erro desconhecido"));
    }
  };

  const handleLogout = async () => {
    await logoutUser();
    setAccount(null);
  };

  const fetchData = async () => {
    if (account) {
      setLoading(true);
      const data = await getFarmingData(account);
      setFarmingData(data);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 10000); // Auto-refresh every 10s
    return () => clearInterval(interval);
  }, [account]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-purple-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <ErrorBoundary>
        <Auth />
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-slate-950 text-white font-sans selection:bg-purple-500/30">
        {/* Navbar */}
        <nav className="border-b border-white/10 bg-slate-900/50 backdrop-blur-md sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-3 sm:px-4 h-16 sm:h-20 flex items-center justify-between">
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="bg-gradient-to-tr from-purple-600 to-blue-600 p-1.5 sm:p-2.5 rounded-xl shadow-lg shadow-purple-500/20">
                <Sprout size={20} className="text-white sm:w-7 sm:h-7" />
              </div>
              <div className="flex flex-col">
                <span className="text-base sm:text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-blue-400 leading-tight">
                  DApp NFT Farm
                </span>
                <span className="text-[10px] sm:text-xs text-gray-400 font-medium tracking-wider">NFT FARM</span>
              </div>
            </div>

            {/* Navigation Links */}
            {account && (
              <div className="flex items-center gap-1 sm:gap-2 bg-white/5 p-1 rounded-full border border-white/5 overflow-x-auto max-w-[200px] sm:max-w-none no-scrollbar">
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className={`px-3 sm:px-5 py-1.5 sm:py-2.5 rounded-full transition-all flex items-center gap-2 text-xs sm:text-sm font-medium whitespace-nowrap ${currentView === 'dashboard'
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                    }`}
                >
                  <span className="sm:hidden">📊</span>
                  <span className="hidden sm:inline">Dashboard</span>
                </button>
                <button
                  onClick={() => setCurrentView('staking')}
                  className={`px-3 sm:px-5 py-1.5 sm:py-2.5 rounded-full transition-all flex items-center gap-2 text-xs sm:text-sm font-medium whitespace-nowrap ${currentView === 'staking'
                    ? 'bg-green-600 text-white shadow-md'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                    }`}
                >
                  <TrendingUp size={14} className="sm:w-4 sm:h-4" />
                  <span className="hidden sm:inline">Staking</span>
                </button>
                <button
                  onClick={() => setCurrentView('egg')}
                  className={`px-3 sm:px-5 py-1.5 sm:py-2.5 rounded-full transition-all flex items-center gap-2 text-xs sm:text-sm font-medium whitespace-nowrap ${currentView === 'egg'
                    ? 'bg-yellow-500 text-black shadow-md'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                    }`}
                >
                  <EggIcon size={14} className="sm:w-4 sm:h-4" />
                  <span className="hidden sm:inline">Comprar Ovo</span>
                </button>
                {isOwner && (
                  <button
                    onClick={() => setCurrentView('admin')}
                    className={`px-3 sm:px-5 py-1.5 sm:py-2.5 rounded-full transition-all flex items-center gap-2 text-xs sm:text-sm font-medium whitespace-nowrap ${currentView === 'admin'
                      ? 'bg-red-600 text-white shadow-md'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                      }`}
                  >
                    <Shield size={14} className="sm:w-4 sm:h-4" />
                    <span className="hidden sm:inline">Admin</span>
                  </button>
                )}
              </div>
            )}

            <div className="flex items-center gap-3">
              <div className="hidden sm:block">
                <WalletConnect account={account} onConnect={handleConnect} />
              </div>

              <button
                onClick={handleLogout}
                className="p-2 bg-white/5 hover:bg-red-500/20 text-gray-400 hover:text-red-400 rounded-xl transition-colors"
                title="Sair"
              >
                <LogOut size={20} />
              </button>

              <div className="sm:hidden">
                {/* Mobile Wallet Icon (Simplified) */}
                <div onClick={handleConnect} className="p-2 bg-white/10 rounded-full">
                  <Wallet size={20} className="text-purple-400" />
                </div>
              </div>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="max-w-7xl mx-auto px-3 sm:px-4 py-4 sm:py-8">
          {!account ? (
            <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-4 sm:space-y-6 px-4">
              <div className="w-20 h-20 sm:w-24 sm:h-24 bg-purple-500/10 rounded-full flex items-center justify-center mb-2 sm:mb-4 animate-pulse">
                <Wallet size={40} className="text-purple-400 sm:w-12 sm:h-12" />
              </div>
              <h1 className="text-3xl sm:text-4xl md:text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-b from-white to-slate-400">
                Olá, {user.displayName}
              </h1>
              <p className="text-slate-400 text-sm sm:text-lg max-w-md px-4">
                Para acessar o Dashboard de Farming e comprar Ovos Misteriosos, conecte sua carteira Polygon.
              </p>
              <button
                onClick={handleConnect}
                className="px-6 sm:px-8 py-3 sm:py-4 bg-white text-slate-900 rounded-full font-bold text-base sm:text-lg hover:scale-105 transition-transform shadow-xl shadow-purple-500/20"
              >
                Conectar MetaMask
              </button>
            </div>
          ) : (
            <>
              {currentView === 'dashboard' ? (
                <Dashboard
                  account={account}
                  walletNfts={farmingData?.walletNfts || []}
                  stakedNfts={farmingData?.stakedNfts || []}
                  pendingRewards={farmingData?.pendingRewards || 0}
                  tokenBalance={farmingData?.tokenBalance || 0}
                  totalSpeed={farmingData?.totalSpeed || 0}
                  refreshData={fetchData}
                />
              ) : currentView === 'staking' ? (
                <TokenStaking account={account} refreshData={fetchData} />
              ) : currentView === 'egg' ? (
                <MysteryEgg
                  user={user}
                  account={account}
                  refreshData={fetchData}
                  onNavigateToDashboard={() => setCurrentView('dashboard')}
                />
              ) : (
                <AdminPanel account={account} />
              )}
            </>
          )}
        </main>
      </div>
    </ErrorBoundary>
  );
}

export default App;
