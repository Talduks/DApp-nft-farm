export enum Rarity {
  COMMON = 'Comum',
  RARE = 'Raro',
  LEGENDARY = 'Lendário',
}

export interface NFT {
  id: string;
  name: string;
  image: string;
  rarity: Rarity;
  farmRate: number; // USDT por segundo
  price: number; // Preço estimado em USDT
  isStaked: boolean;
  collectionName: string;
}

export interface UserState {
  walletAddress: string | null;
  isConnected: boolean;
  usdtBalance: number;
  nfts: NFT[];
  pendingRewards: number;
}

export interface FarmConfig {
  apy: number;
  totalValueLocked: number;
}