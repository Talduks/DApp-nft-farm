import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Lock, Clock, DollarSign, Gift } from 'lucide-react';
import {
    getRewardTokenBalance,
    approveTokenStaking,
    stakeTokens,
    unstakeTokens,
    getActiveStakes
} from '../services/web3';
import { logStake, logUnstake } from '../services/firebaseService';

interface StakeData {
    stakeId: number;
    amount: string;
    startTime: number;
    endTime: number;
    lockMonths: number;
    reward: string;
    canWithdraw: boolean;
}

const TokenStaking: React.FC<{ account: string; refreshData: () => void }> = ({ account, refreshData }) => {
    const [balance, setBalance] = useState<number>(0);
    const [selectedPeriod, setSelectedPeriod] = useState<3 | 6 | 12>(3);
    const [stakeAmount, setStakeAmount] = useState<string>('');
    const [activeStakes, setActiveStakes] = useState<StakeData[]>([]);
    const [loading, setLoading] = useState(false);

    const periods = [
        { months: 3, apy: 5.5, color: 'from-blue-500 to-cyan-500' },
        { months: 6, apy: 11, color: 'from-purple-500 to-pink-500' },
        { months: 12, apy: 22, color: 'from-orange-500 to-red-500' }
    ];

    useEffect(() => {
        loadData();
    }, [account]);

    const loadData = async () => {
        try {
            const bal = await getRewardTokenBalance(account);
            setBalance(bal);

            const stakes = await getActiveStakes(account);
            setActiveStakes(stakes);
        } catch (error) {
            console.error('Error loading data:', error);
        }
    };

    const calculateProjectedReward = () => {
        if (!stakeAmount || parseFloat(stakeAmount) === 0) return 0;
        const amount = parseFloat(stakeAmount);
        return (amount * 0.22 * selectedPeriod) / 12;
    };

    const handleStake = async () => {
        if (!stakeAmount || parseFloat(stakeAmount) === 0) {
            alert('Digite um valor válido');
            return;
        }

        setLoading(true);
        try {
            // 1. Approve
            await approveTokenStaking(stakeAmount);

            // 2. Stake
            const tx = await stakeTokens(stakeAmount, selectedPeriod);

            // 3. Log to Firebase
            // Note: We need the stakeId. Since we don't get it directly from the tx receipt easily without parsing logs,
            // we can fetch the latest stake or just use a placeholder/timestamp for now if critical, 
            // but ideally we should parse the event. 
            // For simplicity in this iteration, we'll fetch active stakes again and find the new one or just log the attempt.
            // Better approach: The contract emits Staked event. 
            // Let's just log the basic info we have.
            // To get the real ID we would need to read the events.
            // For now, let's use a timestamp-based ID or just 0 if we can't get it, 
            // but `logStake` expects an ID.
            // Let's assume the next ID is activeStakes.length (approximate, but risky if user has unstaked).
            // A safer way is to reload data and find the new stake.

            // Let's reload data first to get the new stake list
            const oldStakes = activeStakes;
            const bal = await getRewardTokenBalance(account);
            setBalance(bal);
            const newStakes = await getActiveStakes(account);
            setActiveStakes(newStakes);

            // Find the new stake (one that is in newStakes but not in oldStakes)
            const createdStake = newStakes.find(ns => !oldStakes.some(os => os.stakeId === ns.stakeId));

            if (createdStake) {
                logStake({
                    user: account,
                    stakeId: createdStake.stakeId,
                    amount: stakeAmount,
                    lockMonths: selectedPeriod,
                    startTime: createdStake.startTime,
                    endTime: createdStake.endTime,
                    status: 'active',
                    txHash: "pending" // We could pass the tx hash if stakeTokens returned it
                });
            }

            alert(`✅ Stake realizado! Seus tokens estão bloqueados por ${selectedPeriod} meses.`);
            setStakeAmount('');
            refreshData();
        } catch (error: any) {
            console.error(error);
            alert('Erro: ' + (error.message || 'Erro desconhecido'));
        } finally {
            setLoading(false);
        }
    };

    const handleUnstake = async (stakeId: number) => {
        setLoading(true);
        try {
            await unstakeTokens(stakeId);

            // Find the stake to get amount for logging
            const stake = activeStakes.find(s => s.stakeId === stakeId);
            if (stake) {
                logUnstake(
                    account,
                    stakeId,
                    stake.amount,
                    stake.reward,
                    "pending" // tx hash
                );
            }

            alert('✅ Unstake realizado! Tokens + recompensas recebidos.');
            loadData();
            refreshData();
        } catch (error: any) {
            console.error(error);
            alert('Erro: ' + (error.message || 'Erro desconhecido'));
        } finally {
            setLoading(false);
        }
    };

    const formatTimeRemaining = (endTime: number) => {
        const now = Math.floor(Date.now() / 1000);
        const remaining = endTime - now;

        if (remaining <= 0) return 'Disponível para saque!';

        const days = Math.floor(remaining / 86400);
        const hours = Math.floor((remaining % 86400) / 3600);

        return `${days}d ${hours}h restantes`;
    };

    return (
        <div className="w-full max-w-5xl mt-6 sm:mt-8 flex flex-col gap-6 sm:gap-8 px-4 sm:px-0">
            {/* Header */}
            <div className="flex items-center gap-3">
                <div className="p-3 bg-green-500/10 rounded-xl">
                    <TrendingUp className="text-green-500 w-8 h-8" />
                </div>
                <div>
                    <h1 className="text-2xl sm:text-3xl font-bold text-white">Token Staking</h1>
                    <p className="text-gray-400 text-sm">Multiplique seus tokens DAPPF</p>
                </div>
            </div>

            {/* Info Banner & Balance */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="md:col-span-2 bg-gradient-to-r from-green-900/40 to-blue-900/40 border border-green-500/30 rounded-2xl p-6 relative overflow-hidden"
                >
                    <div className="relative z-10">
                        <p className="text-green-400 font-bold mb-1 uppercase text-xs tracking-wider">Rendimento Anual</p>
                        <p className="text-white text-3xl sm:text-4xl font-black mb-2">22% APY</p>
                        <p className="text-gray-300 text-sm max-w-md">
                            Bloqueie seus tokens por um período determinado e receba recompensas garantidas ao final do prazo.
                        </p>
                    </div>
                    <TrendingUp className="absolute right-0 bottom-0 text-green-500/10 w-40 h-40 -mr-8 -mb-8" />
                </motion.div>

                <div className="bg-[#0f172a]/80 border border-white/10 rounded-2xl p-6 flex flex-col justify-center">
                    <p className="text-gray-400 text-xs uppercase font-bold tracking-wider mb-2">Saldo Disponível</p>
                    <p className="text-3xl font-bold text-white truncate" title={balance.toString()}>{balance.toFixed(2)}</p>
                    <p className="text-sm text-gray-500">DAPPF</p>
                </div>
            </div>

            {/* Period Selection */}
            <div>
                <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                    <Clock size={18} className="text-purple-400" />
                    Escolha o Período
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
                    {periods.map((period) => (
                        <motion.button
                            key={period.months}
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => setSelectedPeriod(period.months as 3 | 6 | 12)}
                            className={`relative overflow-hidden rounded-2xl p-5 sm:p-6 border transition-all text-left group ${selectedPeriod === period.months
                                ? 'border-purple-500 bg-purple-500/10 shadow-[0_0_20px_rgba(168,85,247,0.2)]'
                                : 'border-white/10 bg-white/5 hover:border-white/30'
                                }`}
                        >
                            <div className={`absolute inset-0 bg-gradient-to-br ${period.color} opacity-0 group-hover:opacity-10 transition-opacity`} />

                            <div className="flex justify-between items-start mb-4">
                                <div className={`p-2 rounded-lg ${selectedPeriod === period.months ? 'bg-purple-500 text-white' : 'bg-white/10 text-gray-400'}`}>
                                    <Lock size={20} />
                                </div>
                                {selectedPeriod === period.months && (
                                    <span className="bg-purple-500 text-white text-[10px] font-bold px-2 py-1 rounded-full">
                                        SELECIONADO
                                    </span>
                                )}
                            </div>

                            <p className="text-3xl font-black text-white mb-1">{period.apy}%</p>
                            <p className="text-sm text-gray-400 font-medium">{period.months} Meses de Lock</p>
                        </motion.button>
                    ))}
                </div>
            </div>

            {/* Stake Input */}
            <div className="bg-[#0f172a]/60 border border-white/10 rounded-3xl p-5 sm:p-8">
                <h3 className="text-lg font-bold text-white mb-6">Quanto você quer stakear?</h3>

                <div className="flex flex-col sm:flex-row gap-4 mb-6">
                    <div className="flex-1 relative">
                        <input
                            type="number"
                            value={stakeAmount}
                            onChange={(e) => setStakeAmount(e.target.value)}
                            placeholder="0.00"
                            className="w-full bg-[#1e293b] border border-white/10 rounded-xl px-4 py-4 text-white text-xl focus:outline-none focus:border-purple-500 transition-colors"
                        />
                        <button
                            onClick={() => setStakeAmount(balance.toString())}
                            className="absolute right-3 top-1/2 -translate-y-1/2 px-3 py-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-bold text-purple-300 transition-colors"
                        >
                            MAX
                        </button>
                    </div>

                    <button
                        onClick={handleStake}
                        disabled={loading || !stakeAmount || parseFloat(stakeAmount) === 0}
                        className={`sm:w-48 py-4 rounded-xl font-bold text-lg transition-all shadow-lg ${loading || !stakeAmount || parseFloat(stakeAmount) === 0
                            ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                            : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white hover:scale-105'
                            }`}
                    >
                        {loading ? 'Processando...' : 'Confirmar Stake'}
                    </button>
                </div>

                {stakeAmount && parseFloat(stakeAmount) > 0 && (
                    <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4 flex items-center justify-between">
                        <div>
                            <p className="text-green-400 text-xs font-bold uppercase tracking-wider mb-1">Retorno Estimado</p>
                            <p className="text-xl font-bold text-white">+{calculateProjectedReward().toFixed(4)} DAPPF</p>
                        </div>
                        <div className="text-right">
                            <p className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-1">Duração</p>
                            <p className="text-white font-medium">{selectedPeriod} Meses</p>
                        </div>
                    </div>
                )}
            </div>

            {/* Active Stakes */}
            {activeStakes.length > 0 && (
                <div>
                    <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                        <Gift size={18} className="text-pink-400" />
                        Seus Stakes Ativos
                    </h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {activeStakes.map((stake) => (
                            <motion.div
                                key={stake.stakeId}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="bg-[#1e293b]/50 border border-white/5 rounded-2xl p-5 hover:border-white/10 transition-colors"
                            >
                                <div className="flex justify-between items-start mb-6">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-400 font-bold">
                                            #{stake.stakeId}
                                        </div>
                                        <div>
                                            <p className="text-2xl font-bold text-white">{parseFloat(stake.amount).toFixed(2)}</p>
                                            <p className="text-xs text-gray-500">DAPPF Staked</p>
                                        </div>
                                    </div>
                                    <div className="bg-white/5 px-3 py-1 rounded-lg border border-white/5">
                                        <p className="text-gray-300 text-xs font-bold">{stake.lockMonths}M Lock</p>
                                    </div>
                                </div>

                                <div className="space-y-3">
                                    <div className="flex justify-between items-center p-3 bg-black/20 rounded-xl">
                                        <span className="text-gray-400 text-sm">Recompensa</span>
                                        <span className="text-green-400 font-bold">+{parseFloat(stake.reward).toFixed(4)} DAPPF</span>
                                    </div>

                                    <div className="flex justify-between items-center p-3 bg-black/20 rounded-xl">
                                        <span className="text-gray-400 text-sm">Status</span>
                                        <span className={`text-sm font-bold ${stake.canWithdraw ? 'text-green-400' : 'text-yellow-500'}`}>
                                            {formatTimeRemaining(stake.endTime)}
                                        </span>
                                    </div>
                                </div>

                                {stake.canWithdraw && (
                                    <button
                                        onClick={() => handleUnstake(stake.stakeId)}
                                        disabled={loading}
                                        className="w-full mt-4 py-3 bg-green-600 hover:bg-green-500 rounded-xl text-white font-bold transition-all shadow-lg active:scale-95"
                                    >
                                        Resgatar Tudo
                                    </button>
                                )}
                            </motion.div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default TokenStaking;
