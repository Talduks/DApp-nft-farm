import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Egg, Sparkles, Zap } from 'lucide-react';
import { User } from 'firebase/auth';
import { mintNFT } from '../services/web3';
import { logEggMint } from '../services/firebaseService';

interface MysteryEggProps {
    user: User;
    account: string;
    refreshData: () => void;
    onNavigateToDashboard: () => void;
}

const MysteryEgg: React.FC<MysteryEggProps> = ({ user, account, refreshData, onNavigateToDashboard }) => {
    const [isMinting, setIsMinting] = useState(false);
    const [hatchedNft, setHatchedNft] = useState<{ id: number; speed: number } | null>(null);

    const handleBuyEgg = async () => {
        setIsMinting(true);
        setHatchedNft(null);
        try {
            // Call smart contract
            const result = await mintNFT();

            // Log to Firebase using user.uid
            if (user) {
                logEggMint({
                    user: user.uid, // Use UID instead of wallet address
                    tokenId: result.id,
                    speed: result.speed,
                    txHash: "pending_or_from_event"
                });
            }

            // Simulate hatching delay for animation
            setTimeout(() => {
                setHatchedNft(result); // result should contain { id, speed }
                setIsMinting(false);
                refreshData();
            }, 2000);

        } catch (error) {
            console.error(error);
            setIsMinting(false);
            alert("Erro ao comprar ovo. Verifique seu saldo.");
        }
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-[60vh] gap-8 px-4 w-full max-w-lg mx-auto">
            <AnimatePresence mode='wait'>
                {!hatchedNft ? (
                    <motion.div
                        key="egg"
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0, opacity: 0 }}
                        className="relative cursor-pointer group w-full flex flex-col items-center"
                    >
                        <motion.div
                            animate={isMinting ? {
                                rotate: [0, -5, 5, -5, 5, 0],
                                transition: { repeat: Infinity, duration: 0.4 }
                            } : {}}
                            className="relative z-10"
                        >
                            <div className="w-56 h-72 sm:w-72 sm:h-96 bg-gradient-to-b from-yellow-100 to-yellow-500 rounded-[50%_50%_50%_50%_/_60%_60%_40%_40%] shadow-[0_0_50px_rgba(234,179,8,0.2)] sm:shadow-[0_0_80px_rgba(234,179,8,0.3)] flex items-center justify-center border-4 border-yellow-600/20 relative overflow-hidden">
                                <div className="absolute inset-0 bg-gradient-to-tr from-white/40 to-transparent opacity-50" />
                                <span className="text-8xl sm:text-9xl opacity-20 font-black text-yellow-900 select-none">?</span>
                            </div>
                        </motion.div>

                        {/* Glow effect */}
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-yellow-400 blur-[80px] opacity-10 group-hover:opacity-20 transition-opacity rounded-full pointer-events-none" />

                        {!isMinting && (
                            <motion.button
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                                onClick={handleBuyEgg}
                                className="mt-8 sm:mt-12 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-400 hover:to-orange-400 text-black font-bold py-4 px-8 sm:px-10 rounded-full shadow-[0_0_30px_rgba(234,179,8,0.4)] whitespace-nowrap flex items-center gap-3 text-lg sm:text-xl relative z-20"
                            >
                                <Egg size={24} className="text-yellow-900" />
                                Comprar Ovo (1 POL)
                            </motion.button>
                        )}

                        {isMinting && (
                            <div className="mt-8 sm:mt-12 flex flex-col items-center gap-2">
                                <div className="w-8 h-8 border-4 border-yellow-500 border-t-transparent rounded-full animate-spin" />
                                <p className="text-yellow-400 font-bold animate-pulse text-lg">
                                    Chocando...
                                </p>
                            </div>
                        )}
                    </motion.div>
                ) : (
                    <motion.div
                        key="result"
                        initial={{ scale: 0, rotate: 180 }}
                        animate={{ scale: 1, rotate: 0 }}
                        className="bg-[#0f172a] p-1 rounded-[2.5rem] border border-purple-500/50 shadow-2xl w-full max-w-sm relative overflow-hidden"
                    >
                        <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 to-blue-500/20" />

                        <div className="relative bg-[#0f172a] rounded-[2.3rem] p-6 sm:p-8 flex flex-col items-center gap-6">
                            <div className="relative">
                                <Sparkles className="absolute -top-8 -right-8 text-yellow-400 w-16 h-16 animate-spin-slow opacity-50" />
                                <div className="w-40 h-40 sm:w-48 sm:h-48 bg-gradient-to-br from-purple-600 to-indigo-600 rounded-2xl flex items-center justify-center text-6xl sm:text-7xl font-bold text-white shadow-inner border border-white/10">
                                    #{hatchedNft.id}
                                </div>
                            </div>

                            <div className="text-center space-y-2">
                                <h3 className="text-2xl sm:text-3xl font-bold text-white">Você ganhou!</h3>
                                <div className="inline-flex items-center gap-2 text-yellow-400 bg-yellow-400/10 py-2 px-5 rounded-full border border-yellow-400/20">
                                    <Zap size={20} />
                                    <span className="font-bold text-xl">Speed: {hatchedNft.speed}</span>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-3 w-full mt-2">
                                <button
                                    onClick={() => setHatchedNft(null)}
                                    className="px-4 py-3 bg-white/5 hover:bg-white/10 rounded-xl text-white transition-colors text-sm font-bold"
                                >
                                    Abrir outro
                                </button>
                                <button
                                    onClick={onNavigateToDashboard}
                                    className="px-4 py-3 bg-purple-600 hover:bg-purple-500 rounded-xl text-white font-bold shadow-lg transition-colors text-sm"
                                >
                                    Ver Dashboard
                                </button>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default MysteryEgg;
