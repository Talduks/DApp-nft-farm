import React from 'react';
import { NFT, Rarity } from '../types';
import Button from './Button';

interface NFTCardProps {
  nft: NFT;
  onAction: (id: string) => void;
  isLoading: boolean;
}

const NFTCard: React.FC<NFTCardProps> = ({ nft, onAction, isLoading }) => {
  const getRarityColor = (rarity: Rarity) => {
    switch (rarity) {
      case Rarity.LEGENDARY: return "border-yellow-500 text-yellow-400 shadow-[0_0_15px_rgba(234,179,8,0.3)]";
      case Rarity.RARE: return "border-purple-500 text-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.3)]";
      default: return "border-gray-600 text-gray-400";
    }
  };

  return (
    <div className={`glass-panel rounded-2xl p-4 flex flex-col gap-3 transition-all duration-300 hover:-translate-y-2 border-t-2 ${getRarityColor(nft.rarity)}`}>
      <div className="relative w-full aspect-square rounded-xl overflow-hidden group">
        <img 
          src={nft.image} 
          alt={nft.name} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-2 right-2 bg-black/80 backdrop-blur px-2 py-1 rounded text-xs font-bold border border-white/10">
          {nft.rarity}
        </div>
        {nft.isStaked && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center backdrop-blur-sm">
            <div className="text-accent font-bold text-lg animate-pulse">FARMANDO ⚡</div>
          </div>
        )}
      </div>

      <div className="flex-1">
        <h3 className="text-lg font-bold text-white leading-tight">{nft.name}</h3>
        <p className="text-xs text-gray-400">{nft.collectionName}</p>
        
        <div className="mt-3 bg-black/30 rounded-lg p-2 flex justify-between items-center">
          <span className="text-xs text-gray-400">Rendimento</span>
          <span className="text-sm font-mono text-accent">+{nft.farmRate.toFixed(4)} USDT/s</span>
        </div>
      </div>

      <Button 
        variant={nft.isStaked ? 'danger' : 'secondary'}
        onClick={() => onAction(nft.id)}
        isLoading={isLoading}
        className="w-full text-sm py-2"
      >
        {nft.isStaked ? 'Resgatar (Unstake)' : 'Farmar Agora'}
      </Button>
    </div>
  );
};

export default NFTCard;