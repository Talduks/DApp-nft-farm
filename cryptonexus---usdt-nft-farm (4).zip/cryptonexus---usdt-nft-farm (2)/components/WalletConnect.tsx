import React from 'react';
import { Wallet } from 'lucide-react';
import { motion } from 'framer-motion';

interface WalletConnectProps {
    account: string | null;
    onConnect: () => void;
}

const WalletConnect: React.FC<WalletConnectProps> = ({ account, onConnect }) => {
    return (
        <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onConnect}
            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full font-bold text-white shadow-lg hover:shadow-purple-500/50 transition-all"
        >
            <Wallet size={20} />
            {account ? `${account.substring(0, 6)}...${account.substring(account.length - 4)}` : 'Conectar Carteira'}
        </motion.button>
    );
};

export default WalletConnect;
