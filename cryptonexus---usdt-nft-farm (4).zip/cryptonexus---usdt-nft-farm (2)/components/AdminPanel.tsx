import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, DollarSign, AlertCircle, Egg, TrendingUp, Calendar, Filter, Users, Ban, CheckCircle, Search, X, Zap, Wallet } from 'lucide-react';
import {
    checkIsOwner,
    withdrawFromNFTContract,
    getContractBalance,
    EggHistoryItem,
    StakingStats,
    getUserNFTDetails,
    UserNFTDetail
} from '../services/web3';
import { getAdminEggHistory, getAdminStakingStats, getAllUsers, toggleUserBan, UserData } from '../services/firebaseService';

interface AdminPanelProps {
    account: string;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ account }) => {
    const [isOwner, setIsOwner] = useState(false);
    const [contractBalance, setContractBalance] = useState(0);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState<'dashboard' | 'users'>('dashboard');

    // Dashboard Data
    const [eggHistory, setEggHistory] = useState<EggHistoryItem[]>([]);
    const [stakingStats, setStakingStats] = useState<StakingStats | null>(null);
    const [stakingFilter, setStakingFilter] = useState<'all' | 3 | 6 | 12>('all');

    // Users Data
    const [users, setUsers] = useState<UserData[]>([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedUser, setSelectedUser] = useState<UserData | null>(null);
    const [userNFTs, setUserNFTs] = useState<UserNFTDetail[]>([]);
    const [loadingNFTs, setLoadingNFTs] = useState(false);

    useEffect(() => {
        checkOwnership();
    }, [account]);

    useEffect(() => {
        if (isOwner) {
            fetchContractBalance();
            fetchAnalytics();
            fetchUsers();
        }
    }, [isOwner]);

    const checkOwnership = async () => {
        try {
            const owner = await checkIsOwner(account);
            setIsOwner(owner);
        } catch (error) {
            console.error("Error checking ownership:", error);
            setIsOwner(false);
        } finally {
            setLoading(false);
        }
    };

    const fetchContractBalance = async () => {
        try {
            const balance = await getContractBalance();
            setContractBalance(balance);
        } catch (error) {
            console.error("Error fetching balance:", error);
        }
    };

    const fetchAnalytics = async () => {
        try {
            const [history, stats] = await Promise.all([
                getAdminEggHistory(),
                getAdminStakingStats()
            ]);
            setEggHistory(history);
            setStakingStats(stats);
        } catch (error) {
            console.error("Error fetching analytics:", error);
        }
    };

    const fetchUsers = async () => {
        const allUsers = await getAllUsers();
        setUsers(allUsers);
    };

    const handleWithdraw = async () => {
        if (!isOwner) {
            alert("Você não é o proprietário do contrato!");
            return;
        }

        try {
            await withdrawFromNFTContract();
            alert("Saque realizado com sucesso! ✅");
            fetchContractBalance();
        } catch (error: any) {
            console.error(error);
            alert("Erro ao sacar: " + (error.message || "Erro desconhecido"));
        }
    };

    const handleBanToggle = async (uid: string, currentStatus: boolean) => {
        if (!confirm(`Tem certeza que deseja ${currentStatus ? 'desbanir' : 'banir'} este usuário?`)) return;

        try {
            await toggleUserBan(uid, !currentStatus);
            // Optimistic update
            setUsers(users.map(u => u.uid === uid ? { ...u, isBanned: !currentStatus } : u));
        } catch (error) {
            alert("Erro ao atualizar status do usuário.");
        }
    };

    const handleViewNFTs = async (user: UserData) => {
        if (!user.address) {
            alert("Este usuário ainda não conectou uma carteira.");
            return;
        }
        setSelectedUser(user);
        setLoadingNFTs(true);
        setUserNFTs([]);

        try {
            const nfts = await getUserNFTDetails(user.address);
            setUserNFTs(nfts);
        } catch (error) {
            console.error(error);
            alert("Erro ao buscar NFTs.");
        } finally {
            setLoadingNFTs(false);
        }
    };

    const filteredUsers = users.filter(user =>
        user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (user.address && user.address.toLowerCase().includes(searchTerm.toLowerCase()))
    );

    if (loading) {
        return (
            <div className="w-full max-w-5xl mt-12 flex items-center justify-center">
                <p className="text-gray-400 text-lg">Carregando...</p>
            </div>
        );
    }

    if (!isOwner) {
        return (
            <div className="w-full max-w-5xl mt-4 sm:mt-8 md:mt-12 px-4 sm:px-0">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-red-900/20 border border-red-500/50 rounded-xl sm:rounded-2xl p-6 sm:p-8 flex flex-col items-center gap-3 sm:gap-4"
                >
                    <AlertCircle className="text-red-500 w-12 h-12 sm:w-16 sm:h-16" />
                    <h2 className="text-xl sm:text-2xl font-bold text-white">Acesso Negado</h2>
                    <p className="text-gray-400 text-center text-sm sm:text-base">
                        Apenas o proprietário do contrato pode acessar este painel.
                    </p>
                    <p className="text-[10px] sm:text-xs text-gray-500 font-mono break-all text-center">
                        Sua carteira: {account}
                    </p>
                </motion.div>
            </div>
        );
    }

    return (
        <div className="w-full max-w-6xl mt-4 sm:mt-8 md:mt-12 flex flex-col gap-6 sm:gap-8 px-4 sm:px-0 pb-12">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-center gap-3"
                >
                    <Shield className="text-purple-500 w-8 h-8 sm:w-10 sm:h-10" />
                    <h1 className="text-2xl sm:text-3xl font-bold text-white">Painel Admin</h1>
                </motion.div>

                <div className="flex bg-white/5 p-1 rounded-xl border border-white/10">
                    <button
                        onClick={() => setActiveTab('dashboard')}
                        className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'dashboard' ? 'bg-purple-600 text-white shadow-lg' : 'text-gray-400 hover:text-white'
                            }`}
                    >
                        <TrendingUp size={16} />
                        Dashboard
                    </button>
                    <button
                        onClick={() => setActiveTab('users')}
                        className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'users' ? 'bg-purple-600 text-white shadow-lg' : 'text-gray-400 hover:text-white'
                            }`}
                    >
                        <Users size={16} />
                        Usuários
                    </button>
                </div>
            </div>

            {activeTab === 'dashboard' ? (
                <div className="space-y-8">
                    {/* Contract Balance Card */}
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="bg-gradient-to-br from-purple-900/50 to-blue-900/50 border border-purple-500/30 rounded-2xl sm:rounded-3xl p-6 sm:p-8"
                    >
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                            <div className="flex-1">
                                <p className="text-xs sm:text-sm text-gray-400 uppercase mb-2">Saldo do Contrato NFT</p>
                                <p className="text-4xl sm:text-5xl font-bold text-white flex items-baseline gap-2">
                                    {contractBalance.toFixed(4)}
                                    <span className="text-xl sm:text-2xl text-purple-400">POL</span>
                                </p>
                                <p className="text-xs text-gray-500 mt-2">
                                    Taxas acumuladas da mintagem de NFTs
                                </p>
                            </div>
                            <DollarSign className="text-purple-500 w-16 h-16 sm:w-20 sm:h-20 opacity-20 self-end sm:self-auto" />
                        </div>

                        <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={handleWithdraw}
                            disabled={contractBalance === 0}
                            className={`mt-6 w-full py-3 sm:py-4 rounded-xl font-bold text-base sm:text-lg shadow-lg transition-all ${contractBalance > 0
                                ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white'
                                : 'bg-gray-700 text-gray-500 cursor-not-allowed'
                                }`}
                        >
                            {contractBalance > 0 ? '💰 Sacar Fundos' : 'Nenhum fundo disponível'}
                        </motion.button>
                    </motion.div>

                    {/* Staking Stats Section */}
                    {stakingStats && (
                        <div className="space-y-4">
                            <div className="flex items-center justify-between">
                                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                                    <TrendingUp className="text-green-500" />
                                    Estatísticas de Staking
                                </h2>

                                {/* Filter */}
                                <div className="flex bg-white/5 rounded-lg p-1 border border-white/10">
                                    <button
                                        onClick={() => setStakingFilter('all')}
                                        className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${stakingFilter === 'all' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}
                                    >
                                        Todos
                                    </button>
                                    <button
                                        onClick={() => setStakingFilter(3)}
                                        className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${stakingFilter === 3 ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}
                                    >
                                        3 Meses
                                    </button>
                                    <button
                                        onClick={() => setStakingFilter(6)}
                                        className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${stakingFilter === 6 ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}
                                    >
                                        6 Meses
                                    </button>
                                    <button
                                        onClick={() => setStakingFilter(12)}
                                        className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${stakingFilter === 12 ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}
                                    >
                                        12 Meses
                                    </button>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="bg-[#0f172a]/60 border border-white/10 rounded-2xl p-6">
                                    <p className="text-gray-400 text-xs uppercase font-bold tracking-wider mb-2">Total em Stake</p>
                                    <p className="text-3xl font-bold text-white">
                                        {stakingFilter === 'all'
                                            ? stakingStats.totalStaked.toFixed(2)
                                            : stakingStats.totalStakedByPeriod[stakingFilter].toFixed(2)
                                        }
                                        <span className="text-sm text-gray-500 ml-2">DAPPF</span>
                                    </p>
                                </div>
                                <div className="bg-[#0f172a]/60 border border-white/10 rounded-2xl p-6">
                                    <p className="text-gray-400 text-xs uppercase font-bold tracking-wider mb-2">Stakes Ativos</p>
                                    <p className="text-3xl font-bold text-white">
                                        {stakingStats.activeStakesCount}
                                    </p>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Egg History Section */}
                    <div className="space-y-4">
                        <h2 className="text-xl font-bold text-white flex items-center gap-2">
                            <Egg className="text-yellow-500" />
                            Histórico de Compras de Ovos
                        </h2>

                        <div className="bg-[#0f172a]/60 border border-white/10 rounded-2xl overflow-hidden">
                            <div className="overflow-x-auto">
                                <table className="w-full text-left">
                                    <thead className="bg-white/5 text-gray-400 text-xs uppercase">
                                        <tr>
                                            <th className="px-6 py-4">Token ID</th>
                                            <th className="px-6 py-4">Usuário</th>
                                            <th className="px-6 py-4">Velocidade</th>
                                            <th className="px-6 py-4">Bloco</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-white/5">
                                        {eggHistory.length > 0 ? (
                                            eggHistory.map((item) => (
                                                <tr key={item.tokenId} className="hover:bg-white/5 transition-colors">
                                                    <td className="px-6 py-4 font-mono text-purple-400">#{item.tokenId}</td>
                                                    <td className="px-6 py-4 font-mono text-xs text-gray-300">
                                                        {item.user.substring(0, 6)}...{item.user.substring(item.user.length - 4)}
                                                    </td>
                                                    <td className="px-6 py-4">
                                                        <span className={`px-2 py-1 rounded text-xs font-bold ${item.speed > 80 ? 'bg-green-500/20 text-green-400' :
                                                            item.speed > 50 ? 'bg-yellow-500/20 text-yellow-400' :
                                                                'bg-red-500/20 text-red-400'
                                                            }`}>
                                                            {item.speed} SPD
                                                        </span>
                                                    </td>
                                                    <td className="px-6 py-4 text-gray-500 text-sm">
                                                        {item.blockNumber}
                                                    </td>
                                                </tr>
                                            ))
                                        ) : (
                                            <tr>
                                                <td colSpan={4} className="px-6 py-8 text-center text-gray-500">
                                                    Nenhum histórico encontrado.
                                                </td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            ) : (
                <div className="space-y-6">
                    {/* Users Tab */}
                    <div className="flex items-center gap-4 bg-[#0f172a]/60 p-4 rounded-2xl border border-white/10">
                        <Search className="text-gray-400" />
                        <input
                            type="text"
                            placeholder="Buscar por usuário ou carteira..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="bg-transparent border-none focus:outline-none text-white w-full"
                        />
                    </div>

                    <div className="bg-[#0f172a]/60 border border-white/10 rounded-2xl overflow-hidden">
                        <div className="overflow-x-auto">
                            <table className="w-full text-left">
                                <thead className="bg-white/5 text-gray-400 text-xs uppercase">
                                    <tr>
                                        <th className="px-6 py-4">Usuário</th>
                                        <th className="px-6 py-4">Carteira</th>
                                        <th className="px-6 py-4">NFTs Mintados</th>
                                        <th className="px-6 py-4">Total Staked</th>
                                        <th className="px-6 py-4">Status</th>
                                        <th className="px-6 py-4 text-right">Ações</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-white/5">
                                    {filteredUsers.map((user) => (
                                        <tr key={user.uid} className="hover:bg-white/5 transition-colors">
                                            <td className="px-6 py-4 font-bold text-white">{user.username}</td>
                                            <td className="px-6 py-4 font-mono text-xs text-gray-400">
                                                {user.address ? (
                                                    <span className="flex items-center gap-1">
                                                        <Wallet size={12} className="text-purple-400" />
                                                        {user.address.substring(0, 6)}...{user.address.substring(user.address.length - 4)}
                                                    </span>
                                                ) : (
                                                    <span className="text-gray-600 italic">Não conectada</span>
                                                )}
                                            </td>
                                            <td className="px-6 py-4">{user.totalMinted || 0}</td>
                                            <td className="px-6 py-4">{user.totalStaked?.toFixed(2) || '0.00'} DAPPF</td>
                                            <td className="px-6 py-4">
                                                {user.isBanned ? (
                                                    <span className="px-2 py-1 bg-red-500/20 text-red-400 rounded text-xs font-bold flex items-center gap-1 w-fit">
                                                        <Ban size={12} /> Banido
                                                    </span>
                                                ) : (
                                                    <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded text-xs font-bold flex items-center gap-1 w-fit">
                                                        <CheckCircle size={12} /> Ativo
                                                    </span>
                                                )}
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                                <div className="flex items-center justify-end gap-2">
                                                    <button
                                                        onClick={() => handleViewNFTs(user)}
                                                        className="p-2 hover:bg-white/10 rounded-lg text-blue-400 transition-colors"
                                                        title="Ver NFTs"
                                                    >
                                                        <Egg size={18} />
                                                    </button>
                                                    <button
                                                        onClick={() => handleBanToggle(user.uid, user.isBanned || false)}
                                                        className={`p-2 hover:bg-white/10 rounded-lg transition-colors ${user.isBanned ? 'text-green-400' : 'text-red-400'}`}
                                                        title={user.isBanned ? "Desbanir" : "Banir"}
                                                    >
                                                        {user.isBanned ? <CheckCircle size={18} /> : <Ban size={18} />}
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            )}

            {/* NFT Details Modal */}
            <AnimatePresence>
                {selectedUser && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
                        <motion.div
                            initial={{ opacity: 0, scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.9 }}
                            className="bg-slate-900 border border-white/10 rounded-3xl p-6 sm:p-8 w-full max-w-2xl max-h-[80vh] overflow-hidden flex flex-col"
                        >
                            <div className="flex items-center justify-between mb-6">
                                <div>
                                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                                        <Egg className="text-yellow-500" />
                                        NFTs de {selectedUser.username}
                                    </h2>
                                    <p className="text-gray-400 text-sm mt-1">
                                        Carteira: {selectedUser.address}
                                    </p>
                                </div>
                                <button
                                    onClick={() => setSelectedUser(null)}
                                    className="p-2 hover:bg-white/10 rounded-full transition-colors"
                                >
                                    <X size={24} className="text-gray-400" />
                                </button>
                            </div>

                            {loadingNFTs ? (
                                <div className="flex-1 flex items-center justify-center min-h-[200px]">
                                    <div className="w-10 h-10 border-4 border-purple-500 border-t-transparent rounded-full animate-spin" />
                                </div>
                            ) : (
                                <div className="flex-1 overflow-y-auto custom-scrollbar pr-2">
                                    {userNFTs.length > 0 ? (
                                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                                            {userNFTs.map(nft => (
                                                <div key={nft.id} className="bg-white/5 border border-white/10 rounded-xl p-4 flex flex-col items-center gap-3 relative overflow-hidden">
                                                    <div className={`absolute top-2 right-2 px-2 py-0.5 rounded text-[10px] font-bold uppercase ${nft.status === 'staked' ? 'bg-purple-500/20 text-purple-400' : 'bg-blue-500/20 text-blue-400'
                                                        }`}>
                                                        {nft.status}
                                                    </div>

                                                    <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-gray-700 to-gray-800 flex items-center justify-center text-white font-bold text-xl shadow-inner">
                                                        #{nft.id}
                                                    </div>

                                                    <div className="flex items-center gap-1 text-yellow-400 font-bold">
                                                        <Zap size={14} />
                                                        {nft.speed} SPD
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    ) : (
                                        <div className="flex flex-col items-center justify-center py-12 text-gray-500 gap-2">
                                            <Egg size={40} className="opacity-20" />
                                            <p>Nenhum NFT encontrado nesta carteira.</p>
                                        </div>
                                    )}
                                </div>
                            )}
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default AdminPanel;
