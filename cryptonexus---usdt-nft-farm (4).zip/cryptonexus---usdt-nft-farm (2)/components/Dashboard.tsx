import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Zap, Layers, Coins, Wallet } from 'lucide-react';
import { stakeNFT, withdrawNFT, claimAllRewards } from '../services/web3';
import { logRewardClaim } from '../services/firebaseService';

interface DashboardProps {
    account: string;
    walletNfts: number[];
    stakedNfts: number[];
    pendingRewards: number;
    tokenBalance: number;
    totalSpeed: number;
    refreshData: () => void;
}

const NFTCard = ({ id, actionLabel, onAction, color }: any) => (
    <motion.div
        layout
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white/5 border border-white/10 p-4 rounded-xl flex flex-col items-center gap-3"
    >
        <div className={`w-16 h-16 rounded-lg ${color} flex items-center justify-center text-white font-bold text-xl`}>
            #{id}
        </div>
        <button
            onClick={() => onAction(id)}
            className="text-xs px-3 py-1 bg-white/10 hover:bg-white/20 rounded-full transition-colors text-white"
        >
            {actionLabel}
        </button>
    </motion.div>
);

const Dashboard: React.FC<DashboardProps> = ({ account, walletNfts, stakedNfts, pendingRewards, tokenBalance, totalSpeed, refreshData }) => {
    const [liveRewards, setLiveRewards] = useState(pendingRewards);

    useEffect(() => {
        setLiveRewards(pendingRewards);
        if (stakedNfts.length > 0 && totalSpeed > 0) {
            // Rate: 0.0001 FARM per speed unit per second (example based on contract)
            // Adjust this multiplier to match your contract's rewardRate * speed
            const rewardsPerSecond = totalSpeed * 0.0001;
            const interval = setInterval(() => {
                setLiveRewards(prev => prev + (rewardsPerSecond / 10)); // Update every 100ms
            }, 100);
            return () => clearInterval(interval);
        }
    }, [pendingRewards, stakedNfts.length, totalSpeed]);

    const handleStake = async (id: number) => {
        try {
            await stakeNFT(id);
            refreshData();
        } catch (e: any) {
            console.error(e);
            alert("Erro ao fazer Stake: " + (e.message || "Erro desconhecido"));
        }
    };

    const handleUnstake = async (id: number) => {
        try {
            await withdrawNFT(id);
            refreshData();
        } catch (e: any) {
            console.error(e);
            alert("Erro ao fazer Withdraw: " + (e.message || "Erro desconhecido"));
        }
    };

    const handleClaim = async () => {
        try {
            await claimAllRewards(stakedNfts);

            // Log to Firebase
            if (account) {
                logRewardClaim(
                    account,
                    liveRewards.toFixed(6), // Aproximado, ideal seria pegar do evento
                    "pending" // tx hash
                );
            }

            refreshData();
        } catch (e: any) {
            console.error(e);
            alert("Erro ao clamar recompensas: " + (e.message || "Erro desconhecido"));
        }
    };

    return (
        <div className="w-full max-w-6xl mt-4 sm:mt-8 flex flex-col gap-6 sm:gap-8 px-2 sm:px-0">
            {/* Stats Row */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                <div className="bg-white/5 backdrop-blur-md p-4 rounded-2xl border border-white/10 flex flex-col gap-2">
                    <div className="flex items-center gap-2 text-gray-400 text-xs uppercase font-bold tracking-wider">
                        <Coins size={14} className="text-yellow-500" />
                        Saldo DAPPF
                    </div>
                    <p className="text-2xl sm:text-3xl font-bold text-white">{tokenBalance.toFixed(2)}</p>
                </div>

                <div className="bg-white/5 backdrop-blur-md p-4 rounded-2xl border border-white/10 flex flex-col gap-2">
                    <div className="flex items-center gap-2 text-gray-400 text-xs uppercase font-bold tracking-wider">
                        <Zap size={14} className="text-blue-500" />
                        Velocidade
                    </div>
                    <p className="text-2xl sm:text-3xl font-bold text-white">{totalSpeed} <span className="text-sm font-normal text-gray-500">SPD</span></p>
                </div>

                <div className="col-span-2 lg:col-span-2 bg-gradient-to-r from-purple-900/40 to-pink-900/40 backdrop-blur-md p-4 rounded-2xl border border-purple-500/30 flex items-center justify-between gap-4">
                    <div>
                        <p className="text-xs text-purple-300 uppercase font-bold tracking-wider mb-1">Recompensas Pendentes</p>
                        <p className="text-2xl sm:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
                            {liveRewards.toFixed(6)}
                        </p>
                    </div>
                    <button
                        onClick={handleClaim}
                        className="px-6 py-3 bg-white text-purple-900 hover:bg-purple-50 rounded-xl font-bold text-sm shadow-lg transition-all active:scale-95"
                    >
                        Resgatar
                    </button>
                </div>
            </div>

            {/* Main Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
                {/* Wallet Inventory */}
                <div className="bg-[#0f172a]/60 rounded-3xl p-5 sm:p-6 border border-white/5">
                    <div className="flex items-center justify-between mb-6">
                        <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                            <Layers size={20} className="text-blue-400" />
                            Sua Carteira
                            <span className="bg-blue-500/20 text-blue-400 text-xs px-2 py-0.5 rounded-full">{walletNfts.length}</span>
                        </h3>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                        {walletNfts.map(id => (
                            <NFTCard
                                key={id}
                                id={id}
                                actionLabel="Stake"
                                onAction={handleStake}
                                color="bg-gradient-to-br from-blue-600 to-blue-700"
                            />
                        ))}
                        {walletNfts.length === 0 && (
                            <div className="col-span-full flex flex-col items-center justify-center py-12 text-gray-500 gap-2">
                                <Layers size={32} className="opacity-20" />
                                <p className="text-sm">Nenhum NFT na carteira</p>
                            </div>
                        )}
                    </div>
                </div>

                {/* Staked Inventory */}
                <div className="bg-[#0f172a]/60 rounded-3xl p-5 sm:p-6 border border-purple-500/20 shadow-[0_0_40px_rgba(168,85,247,0.05)]">
                    <div className="flex items-center justify-between mb-6">
                        <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                            <Zap size={20} className="text-purple-400" />
                            Em Staking
                            <span className="bg-purple-500/20 text-purple-400 text-xs px-2 py-0.5 rounded-full">{stakedNfts.length}</span>
                        </h3>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                        {stakedNfts.map(id => (
                            <NFTCard
                                key={id}
                                id={id}
                                actionLabel="Sacar"
                                onAction={handleUnstake}
                                color="bg-gradient-to-br from-purple-600 to-purple-700"
                            />
                        ))}
                        {stakedNfts.length === 0 && (
                            <div className="col-span-full flex flex-col items-center justify-center py-12 text-gray-500 gap-2">
                                <Zap size={32} className="opacity-20" />
                                <p className="text-sm">Nenhum NFT em Staking</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
            {/* Wallet Info Card */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="bg-[#0f172a]/60 border border-white/10 rounded-3xl p-6 sm:p-8 relative overflow-hidden group"
            >
                <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 group-hover:bg-blue-500/20 transition-all duration-500" />

                <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div>
                        <h3 className="text-gray-400 text-sm font-bold uppercase tracking-wider mb-1 flex items-center gap-2">
                            <Wallet size={16} className="text-blue-500" />
                            Carteira Vinculada
                        </h3>
                        <p className="text-xl sm:text-2xl font-bold text-white font-mono">
                            {account.substring(0, 6)}...{account.substring(account.length - 4)}
                        </p>
                        <p className="text-xs text-gray-500 mt-2">
                            Esta carteira está vinculada à sua conta. Para segurança, alterações são permitidas apenas a cada 7 dias.
                        </p>
                    </div>
                    {/* Future: Add button to manually trigger re-link/change if needed, handled by App.tsx logic */}
                </div>
            </motion.div>

        </div>
    );
};

export default Dashboard;
