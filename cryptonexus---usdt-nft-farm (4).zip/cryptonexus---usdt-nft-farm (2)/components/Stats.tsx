import React from 'react';
import Button from './Button';

interface StatsProps {
  balance: number;
  pendingRewards: number;
  totalStaked: number;
  onClaim: () => void;
  isClaiming: boolean;
}

const Stats: React.FC<StatsProps> = ({ balance, pendingRewards, totalStaked, onClaim, isClaiming }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
      {/* Wallet Balance */}
      <div className="glass-panel p-6 rounded-2xl border-l-4 border-l-primary">
        <div className="text-gray-400 text-sm mb-1 uppercase tracking-wider">Saldo na Carteira</div>
        <div className="text-3xl font-bold text-white font-mono">
          {balance.toFixed(2)} <span className="text-primary text-lg">USDT</span>
        </div>
      </div>

      {/* Farm Stats */}
      <div className="glass-panel p-6 rounded-2xl border-l-4 border-l-purple-500 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10">
            <svg className="w-24 h-24" fill="currentColor" viewBox="0 0 20 20"><path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"></path></svg>
        </div>
        <div className="text-gray-400 text-sm mb-1 uppercase tracking-wider">NFTs em Farm</div>
        <div className="text-3xl font-bold text-white">
          {totalStaked} <span className="text-sm font-normal text-gray-400">Ativos</span>
        </div>
      </div>

      {/* Rewards & Claim */}
      <div className="glass-panel p-6 rounded-2xl border-l-4 border-l-accent bg-gradient-to-r from-green-900/20 to-transparent">
        <div className="flex justify-between items-start">
          <div>
            <div className="text-accent text-sm mb-1 uppercase tracking-wider font-bold">Recompensas Farmadas</div>
            <div className="text-3xl font-bold text-white font-mono animate-pulse">
              {pendingRewards.toFixed(6)} <span className="text-accent text-lg">USDT</span>
            </div>
          </div>
          <Button 
            variant="primary" 
            onClick={onClaim}
            isLoading={isClaiming}
            disabled={pendingRewards <= 0}
            className="px-4 py-2 text-sm"
          >
            Resgatar
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Stats;