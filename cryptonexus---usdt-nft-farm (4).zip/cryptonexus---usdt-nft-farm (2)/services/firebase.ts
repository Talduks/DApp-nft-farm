import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import { getDatabase } from "firebase/database";
import { getAuth } from "firebase/auth";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDTUnfxVVdv64rQMAbleDATTunKCNPA4Q4",
    authDomain: "dapp-farm.firebaseapp.com",
    databaseURL: "https://dapp-farm-default-rtdb.firebaseio.com",
    projectId: "dapp-farm",
    storageBucket: "dapp-farm.firebasestorage.app",
    messagingSenderId: "291109797810",
    appId: "1:291109797810:web:7c73e6a27e77a327cd6eab",
    measurementId: "G-VE179176BK"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getFirestore(app);
const rtdb = getDatabase(app);
const auth = getAuth(app);

export { app, analytics, db, rtdb, auth };
