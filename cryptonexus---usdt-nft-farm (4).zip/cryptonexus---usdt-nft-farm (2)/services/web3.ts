import { ethers } from 'ethers';


// Replace with your deployed contract addresses
const FARM_CONTRACT_ADDRESS = "0xb5829059dFC7bE8F109f118b587e2dD88c911387";
const NFT_COLLECTION_ADDRESS = "0x4B4f7dE54aF4251F83f6739D7F0bA466DA842765";
const REWARD_TOKEN_ADDRESS = "0xA68CF5cC2279Fc2b8547A95cBF5D757f267d5085";
export const STAKING_CONTRACT_ADDRESS = "0x3AD9F072e6bE69d58c43a24e9d576eBC1f4AC0C7"; // Deployed on Polygon

// ABIs
const FARM_ABI = [
    "function stake(uint256 tokenId) external",
    "function withdraw(uint256 tokenId) external",
    "function claimReward(uint256 tokenId) external",
    "function calculateReward(uint256 tokenId) public view returns (uint256)",
    "function getStakedTokens(address user) external view returns (uint256[])",
    "function getTotalClaimable(address user) external view returns (uint256)",
    "function owner() view returns (address)"
];

export const checkIsOwner = async (address: string): Promise<boolean> => {
    if (!window.ethereum || !address) return false;
    try {
        const provider = new ethers.BrowserProvider(window.ethereum);
        const farmContract = new ethers.Contract(FARM_CONTRACT_ADDRESS, FARM_ABI, provider);
        const owner = await farmContract.owner();
        return owner.toLowerCase() === address.toLowerCase();
    } catch (error) {
        console.error("Error checking owner:", error);
        return false;
    }
};

const NFT_ABI = [
    "function balanceOf(address owner) view returns (uint256)",
    "function tokenOfOwnerByIndex(address owner, uint256 index) view returns (uint256)",
    "function approve(address to, uint256 tokenId) external",
    "function getApproved(uint256 tokenId) view returns (address)",
    "function isApprovedForAll(address owner, address operator) view returns (bool)",
    "function setApprovalForAll(address operator, bool approved) external",
    "function tokenURI(uint256 tokenId) view returns (string)",
    "function getFarmingSpeed(uint256 tokenId) external view returns (uint256)",
    "function publicMint() external payable",
    "function owner() view returns (address)",
    "function withdraw() external",
    "event NftMinted(address indexed user, uint256 tokenId, uint256 speed)"
];

const TOKEN_ABI = [
    "function balanceOf(address account) view returns (uint256)",
    "function approve(address spender, uint256 amount) external returns (bool)",
    "function allowance(address owner, address spender) view returns (uint256)"
];

const STAKING_ABI = [
    "function stake(uint256 amount, uint8 lockMonths) external",
    "function unstake(uint256 stakeId) external",
    "function getActiveStakes(address user) external view returns (uint256[] stakeIds, uint256[] amounts, uint256[] startTimes, uint256[] endTimes, uint256[] lockMonths, uint256[] rewards)",
    "function calculateReward(address user, uint256 stakeId) public view returns (uint256)"
];

// Polygon Mainnet Params
const POLYGON_CHAIN_ID = '0x89'; // 137 in hex
const POLYGON_RPC_URL = 'https://polygon-rpc.com/';

export const connectWallet = async () => {
    if (window.ethereum) {
        try {
            const provider = new ethers.BrowserProvider(window.ethereum);
            const accounts = await provider.send("eth_requestAccounts", []);

            const network = await provider.getNetwork();
            if (network.chainId !== 137n) {
                await switchToPolygon();
            }

            return accounts[0];
        } catch (error) {
            console.error("Error connecting wallet:", error);
            throw error;
        }
    } else {
        throw new Error("MetaMask not installed");
    }
};

export const checkWalletConnection = async () => {
    if (window.ethereum) {
        try {
            const provider = new ethers.BrowserProvider(window.ethereum);
            const accounts = await provider.send("eth_accounts", []);
            if (accounts.length > 0) {
                return accounts[0];
            }
        } catch (error) {
            console.error("Error checking connection:", error);
        }
    }
    return null;
};

export const switchToPolygon = async () => {
    if (!window.ethereum) return;
    try {
        await window.ethereum.request({
            method: 'wallet_switchEthereumChain',
            params: [{ chainId: POLYGON_CHAIN_ID }],
        });
    } catch (switchError: any) {
        if (switchError.code === 4902) {
            try {
                await window.ethereum.request({
                    method: 'wallet_addEthereumChain',
                    params: [
                        {
                            chainId: POLYGON_CHAIN_ID,
                            chainName: 'Polygon Mainnet',
                            rpcUrls: [POLYGON_RPC_URL],
                            nativeCurrency: {
                                name: 'POL',
                                symbol: 'POL',
                                decimals: 18,
                            },
                            blockExplorerUrls: ['https://polygonscan.com/'],
                        },
                    ],
                });
            } catch (addError) {
                console.error("Failed to add Polygon network", addError);
            }
        }
    }
}

export const getFarmingData = async (userAddress: string) => {
    if (!window.ethereum) return {
        walletNfts: [],
        stakedNfts: [],
        pendingRewards: 0,
        tokenBalance: 0
    };

    const provider = new ethers.BrowserProvider(window.ethereum);

    // Simulation Mode (if addresses are placeholders)
    if (FARM_CONTRACT_ADDRESS.includes("YOUR_")) {
        return {
            walletNfts: [0, 1, 2], // Dummy IDs
            stakedNfts: [],
            pendingRewards: 0,
            tokenBalance: 0
        };
    }

    try {
        const nftContract = new ethers.Contract(NFT_COLLECTION_ADDRESS, NFT_ABI, provider);
        const farmContract = new ethers.Contract(FARM_CONTRACT_ADDRESS, FARM_ABI, provider);
        const tokenContract = new ethers.Contract(REWARD_TOKEN_ADDRESS, TOKEN_ABI, provider);

        // 1. Get Wallet NFTs (using Enumerable)
        const balance = await nftContract.balanceOf(userAddress);
        const walletNfts = [];
        for (let i = 0; i < Number(balance); i++) {
            try {
                const tokenId = await nftContract.tokenOfOwnerByIndex(userAddress, i);
                walletNfts.push(Number(tokenId));
            } catch (e) {
                console.warn("Error fetching token index", i);
            }
        }

        // 2. Get Staked NFTs and Calculate Total Speed
        const stakedTokens = await farmContract.getStakedTokens(userAddress);
        const stakedNfts = stakedTokens.map((id: bigint) => Number(id));

        let totalSpeed = 0;
        for (const id of stakedNfts) {
            try {
                const speed = await nftContract.getFarmingSpeed(id);
                totalSpeed += Number(speed);
            } catch (e) {
                console.error("Error fetching speed for token", id, e);
            }
        }

        // 3. Get Rewards & Balance
        const pendingRewards = await farmContract.getTotalClaimable(userAddress);
        const tokenBalance = await tokenContract.balanceOf(userAddress);

        return {
            walletNfts,
            stakedNfts,
            totalSpeed,
            pendingRewards: Number(ethers.formatEther(pendingRewards)),
            tokenBalance: Number(ethers.formatEther(tokenBalance))
        };
    } catch (e) {
        console.error("Error fetching data", e);
        return { walletNfts: [], stakedNfts: [], totalSpeed: 0, pendingRewards: 0, tokenBalance: 0 };
    }
};

export const stakeNFT = async (tokenId: number) => {
    if (!window.ethereum) return;
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const nftContract = new ethers.Contract(NFT_COLLECTION_ADDRESS, NFT_ABI, signer);
    const farmContract = new ethers.Contract(FARM_CONTRACT_ADDRESS, FARM_ABI, signer);

    try {
        // Check approval - normalize addresses to lowercase for comparison
        const approvedAddress = await nftContract.getApproved(tokenId);
        const userAddress = await signer.getAddress();
        const isApprovedForAll = await nftContract.isApprovedForAll(userAddress, FARM_CONTRACT_ADDRESS);

        const isAlreadyApproved =
            approvedAddress.toLowerCase() === FARM_CONTRACT_ADDRESS.toLowerCase() ||
            isApprovedForAll;

        if (!isAlreadyApproved) {
            console.log("Approving NFT for staking...");
            const approveTx = await nftContract.approve(FARM_CONTRACT_ADDRESS, tokenId);
            await approveTx.wait();
            console.log("NFT approved!");
        }

        console.log("Staking NFT...");
        const stakeTx = await farmContract.stake(tokenId);
        await stakeTx.wait();
        console.log("NFT staked successfully!");
    } catch (error: any) {
        console.error("Stake error:", error);
        throw new Error(error.reason || error.message || "Unknown error");
    }
};

export const withdrawNFT = async (tokenId: number) => {
    if (!window.ethereum) return;
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const farmContract = new ethers.Contract(FARM_CONTRACT_ADDRESS, FARM_ABI, signer);

    const tx = await farmContract.withdraw(tokenId);
    await tx.wait();
};

export const claimReward = async (tokenId: number) => {
    if (!window.ethereum) return;
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const farmContract = new ethers.Contract(FARM_CONTRACT_ADDRESS, FARM_ABI, signer);

    const tx = await farmContract.claimReward(tokenId);
    await tx.wait();
};

export const claimAllRewards = async (tokenIds: number[]) => {
    if (!window.ethereum) return;
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const farmContract = new ethers.Contract(FARM_CONTRACT_ADDRESS, FARM_ABI, signer);

    for (const id of tokenIds) {
        try {
            const tx = await farmContract.claimReward(id);
            await tx.wait();
        } catch (e) {
            console.error("Failed to claim for", id, e);
        }
    }
};

export const mintNFT = async () => {
    if (!window.ethereum) throw new Error("No wallet");
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const nftContract = new ethers.Contract(NFT_COLLECTION_ADDRESS, NFT_ABI, signer);

    // Listen for event to get the random speed and ID
    // Note: In a real app, we might want to query the event logs after the tx confirms
    // instead of setting up a listener that might miss it or be flaky.
    // For simplicity, we'll parse the receipt logs.

    const tx = await nftContract.publicMint({ value: ethers.parseEther("1.0") }); // 1 POL price
    const receipt = await tx.wait();

    // Parse logs to find the event
    for (const log of receipt.logs) {
        try {
            const parsed = nftContract.interface.parseLog(log);
            if (parsed && parsed.name === "NftMinted") {
                return {
                    id: Number(parsed.args.tokenId),
                    speed: Number(parsed.args.speed)
                };
            }
        } catch (e) {
            // ignore other events
        }
    }

    // Fallback if event parsing fails
    return { id: 0, speed: 0 };
};

// ============== ADMIN FUNCTIONS ==============



export const getContractBalance = async (): Promise<number> => {
    if (!window.ethereum) return 0;
    try {
        const provider = new ethers.BrowserProvider(window.ethereum);
        const balance = await provider.getBalance(NFT_COLLECTION_ADDRESS);
        return Number(ethers.formatEther(balance));
    } catch (error) {
        console.error("Error getting contract balance:", error);
        return 0;
    }
};

export const withdrawFromNFTContract = async () => {
    if (!window.ethereum) throw new Error("No wallet");
    try {
        const provider = new ethers.BrowserProvider(window.ethereum);
        const signer = await provider.getSigner();
        const nftContract = new ethers.Contract(NFT_COLLECTION_ADDRESS, NFT_ABI, signer);

        const tx = await nftContract.withdraw();
        await tx.wait();

        console.log("Withdraw successful!");
    } catch (error: any) {
        console.error("Withdraw error:", error);
        throw new Error(error.reason || error.message || "Unknown error");
    }
};

// ============== STAKING FUNCTIONS ==============

export const getRewardTokenBalance = async (userAddress: string) => {
    if (!window.ethereum) return 0;
    const provider = new ethers.BrowserProvider(window.ethereum);
    const tokenContract = new ethers.Contract(REWARD_TOKEN_ADDRESS, TOKEN_ABI, provider);
    const balance = await tokenContract.balanceOf(userAddress);
    return Number(ethers.formatEther(balance));
};

export const approveTokenStaking = async (amount: string) => {
    if (!window.ethereum) throw new Error("No wallet");
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const tokenContract = new ethers.Contract(REWARD_TOKEN_ADDRESS, TOKEN_ABI, signer);

    const weiAmount = ethers.parseEther(amount);
    const tx = await tokenContract.approve(STAKING_CONTRACT_ADDRESS, weiAmount);
    await tx.wait();
};

export const stakeTokens = async (amount: string, lockMonths: number) => {
    if (!window.ethereum) throw new Error("No wallet");
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const stakingContract = new ethers.Contract(STAKING_CONTRACT_ADDRESS, STAKING_ABI, signer);

    const weiAmount = ethers.parseEther(amount);
    const tx = await stakingContract.stake(weiAmount, lockMonths);
    await tx.wait();
};

export const unstakeTokens = async (stakeId: number) => {
    if (!window.ethereum) throw new Error("No wallet");
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const stakingContract = new ethers.Contract(STAKING_CONTRACT_ADDRESS, STAKING_ABI, signer);

    const tx = await stakingContract.unstake(stakeId);
    await tx.wait();
};

export const getActiveStakes = async (userAddress: string) => {
    if (!window.ethereum) return [];

    // Simulation if address is placeholder
    if (STAKING_CONTRACT_ADDRESS.startsWith("0x0000")) {
        return [];
    }

    try {
        const provider = new ethers.BrowserProvider(window.ethereum);
        const stakingContract = new ethers.Contract(STAKING_CONTRACT_ADDRESS, STAKING_ABI, provider);

        const data = await stakingContract.getActiveStakes(userAddress);
        // data is [stakeIds, amounts, startTimes, endTimes, lockMonths, rewards]

        const stakes = [];
        for (let i = 0; i < data[0].length; i++) {
            stakes.push({
                stakeId: Number(data[0][i]),
                amount: ethers.formatEther(data[1][i]),
                startTime: Number(data[2][i]),
                endTime: Number(data[3][i]),
                lockMonths: Number(data[4][i]),
                reward: ethers.formatEther(data[5][i]),
                canWithdraw: Date.now() / 1000 >= Number(data[3][i])
            });
        }
        return stakes;
    } catch (error) {
        console.error("Error fetching stakes:", error);
        return [];
    }
};

// --- Admin & Analytics Functions ---

export interface EggHistoryItem {
    user: string;
    tokenId: number;
    speed: number;
    txHash: string;
    blockNumber: number;
}

export interface StakingStats {
    totalStaked: number;
    totalStakedByPeriod: {
        3: number;
        6: number;
        12: number;
    };
    activeStakesCount: number;
}

export const getEggHistory = async (): Promise<EggHistoryItem[]> => {
    try {
        if (!window.ethereum) return [];
        const provider = new ethers.BrowserProvider(window.ethereum);
        const nftContract = new ethers.Contract(NFT_COLLECTION_ADDRESS, SPEED_NFT_ABI, provider);

        // Query all NftMinted events
        // event NftMinted(address indexed user, uint256 tokenId, uint256 speed);
        const filter = nftContract.filters.NftMinted();
        const events = await nftContract.queryFilter(filter);

        const history: EggHistoryItem[] = events.map((event: any) => ({
            user: event.args[0],
            tokenId: Number(event.args[1]),
            speed: Number(event.args[2]),
            txHash: event.transactionHash,
            blockNumber: event.blockNumber
        }));

        // Sort by most recent (descending block number)
        return history.sort((a, b) => b.blockNumber - a.blockNumber);
    } catch (error) {
        console.error("Error fetching egg history:", error);
        return [];
    }
};

export const getStakingGlobalStats = async (): Promise<StakingStats> => {
    try {
        if (!window.ethereum) return { totalStaked: 0, totalStakedByPeriod: { 3: 0, 6: 0, 12: 0 }, activeStakesCount: 0 };
        const provider = new ethers.BrowserProvider(window.ethereum);
        const stakingContract = new ethers.Contract(STAKING_CONTRACT_ADDRESS, STAKING_ABI, provider);

        // 1. Get all Staked events
        const stakedFilter = stakingContract.filters.Staked();
        const stakedEvents = await stakingContract.queryFilter(stakedFilter);

        // 2. Get all Unstaked events
        const unstakedFilter = stakingContract.filters.Unstaked();
        const unstakedEvents = await stakingContract.queryFilter(unstakedFilter);

        // Map unstaked events for quick lookup: stakeId -> true
        // Note: stakeIds are unique per user, but globally stakeId is just a counter per user? 
        // Wait, looking at contract: stakeCount[msg.sender] is used as ID. So IDs are NOT globally unique.
        // ID is unique only combined with User address.
        const unstakedMap = new Set<string>();
        unstakedEvents.forEach((event: any) => {
            const user = event.args[0];
            const stakeId = event.args[1];
            unstakedMap.add(`${user}-${stakeId}`);
        });

        let totalStaked = 0;
        const totalStakedByPeriod = { 3: 0, 6: 0, 12: 0 };
        let activeStakesCount = 0;

        stakedEvents.forEach((event: any) => {
            const user = event.args[0];
            const stakeId = event.args[1];
            const amount = parseFloat(ethers.formatEther(event.args[2]));
            const lockMonths = Number(event.args[3]) as 3 | 6 | 12;

            // Check if this stake has been unstaked
            if (!unstakedMap.has(`${user}-${stakeId}`)) {
                totalStaked += amount;
                if (totalStakedByPeriod[lockMonths] !== undefined) {
                    totalStakedByPeriod[lockMonths] += amount;
                }
                activeStakesCount++;
            }
        });

        return {
            totalStaked,
            totalStakedByPeriod,
            activeStakesCount
        };

    } catch (error) {
        console.error("Error fetching staking stats:", error);
        return { totalStaked: 0, totalStakedByPeriod: { 3: 0, 6: 0, 12: 0 }, activeStakesCount: 0 };
    }
};
// --- User Inspection Functions ---

export interface UserNFTDetail {
    id: number;
    speed: number;
    status: 'wallet' | 'staked';
}

export const getUserNFTDetails = async (targetAddress: string): Promise<UserNFTDetail[]> => {
    if (!window.ethereum) return [];

    // Validate address
    if (!ethers.isAddress(targetAddress)) return [];

    try {
        const provider = new ethers.BrowserProvider(window.ethereum);
        const nftContract = new ethers.Contract(NFT_COLLECTION_ADDRESS, NFT_ABI, provider);
        const farmContract = new ethers.Contract(FARM_CONTRACT_ADDRESS, FARM_ABI, provider);

        const details: UserNFTDetail[] = [];

        // 1. Get Wallet NFTs
        const balance = await nftContract.balanceOf(targetAddress);
        for (let i = 0; i < Number(balance); i++) {
            try {
                const tokenId = await nftContract.tokenOfOwnerByIndex(targetAddress, i);
                const speed = await nftContract.getFarmingSpeed(tokenId);
                details.push({
                    id: Number(tokenId),
                    speed: Number(speed),
                    status: 'wallet'
                });
            } catch (e) {
                console.warn("Error fetching wallet token", i);
            }
        }

        // 2. Get Staked NFTs
        const stakedTokens = await farmContract.getStakedTokens(targetAddress);
        for (const id of stakedTokens) {
            try {
                const speed = await nftContract.getFarmingSpeed(id);
                details.push({
                    id: Number(id),
                    speed: Number(speed),
                    status: 'staked'
                });
            } catch (e) {
                console.warn("Error fetching staked token", id);
            }
        }

        return details.sort((a, b) => a.id - b.id);
    } catch (error) {
        console.error("Error fetching user NFT details:", error);
        return [];
    }
};
