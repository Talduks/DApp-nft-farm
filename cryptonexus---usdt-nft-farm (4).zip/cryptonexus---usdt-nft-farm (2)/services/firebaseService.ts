import { db } from './firebase';
import { collection, addDoc, doc, setDoc, updateDoc, increment, serverTimestamp, getDocs, query, orderBy, where } from 'firebase/firestore';

// --- Interfaces ---

export interface EggMintLog {
    user: string;
    tokenId: number;
    speed: number;
    txHash: string;
    timestamp?: any;
}

export interface StakeLog {
    user: string;
    stakeId: number;
    amount: string;
    lockMonths: number;
    startTime: number;
    endTime: number;
    status: 'active' | 'withdrawn';
    txHash: string;
    timestamp?: any;
}

export interface WithdrawalLog {
    user: string;
    amount: string;
    type: 'unstake' | 'claim_rewards';
    txHash: string;
    timestamp?: any;
}

// --- Functions ---

/**
 * Logs a new Egg Mint event
 */
export const logEggMint = async (data: EggMintLog) => {
    try {
        // 1. Add to history collection
        await addDoc(collection(db, 'egg_mints'), {
            ...data,
            timestamp: serverTimestamp()
        });

        // 2. Update user stats
        const userRef = doc(db, 'users', data.user);
        await setDoc(userRef, {
            address: data.user,
            totalMinted: increment(1),
            lastActive: serverTimestamp()
        }, { merge: true });

        console.log("Egg mint logged to Firebase");
    } catch (error) {
        console.error("Error logging egg mint:", error);
    }
};

/**
 * Logs a new Stake event
 */
export const logStake = async (data: StakeLog) => {
    try {
        // 1. Add to stakes collection
        // We use a composite ID to easily find it later if needed: user_stakeId
        const docId = `${data.user}_${data.stakeId}`;
        await setDoc(doc(db, 'stakes', docId), {
            ...data,
            timestamp: serverTimestamp()
        });

        // 2. Update user stats
        const userRef = doc(db, 'users', data.user);
        await setDoc(userRef, {
            address: data.user,
            totalStaked: increment(parseFloat(data.amount)),
            activeStakes: increment(1),
            lastActive: serverTimestamp()
        }, { merge: true });

        console.log("Stake logged to Firebase");
    } catch (error) {
        console.error("Error logging stake:", error);
    }
};

/**
 * Logs an Unstake event (updates stake status and logs withdrawal)
 */
export const logUnstake = async (user: string, stakeId: number, amount: string, reward: string, txHash: string) => {
    try {
        // 1. Update stake status
        const stakeDocId = `${user}_${stakeId}`;
        const stakeRef = doc(db, 'stakes', stakeDocId);
        await updateDoc(stakeRef, {
            status: 'withdrawn',
            withdrawalTxHash: txHash,
            withdrawalTimestamp: serverTimestamp()
        });

        // 2. Log withdrawal (Principal + Reward)
        const totalAmount = parseFloat(amount) + parseFloat(reward);
        await addDoc(collection(db, 'withdrawals'), {
            user,
            amount: totalAmount.toString(),
            principal: amount,
            reward: reward,
            type: 'unstake',
            txHash,
            timestamp: serverTimestamp()
        });

        // 3. Update user stats
        const userRef = doc(db, 'users', user);
        await setDoc(userRef, {
            totalStaked: increment(-parseFloat(amount)), // Decrease active staked amount
            activeStakes: increment(-1),
            totalRewardsClaimed: increment(parseFloat(reward)),
            lastActive: serverTimestamp()
        }, { merge: true });

        console.log("Unstake logged to Firebase");
    } catch (error) {
        console.error("Error logging unstake:", error);
    }
};

/**
 * Logs a Reward Claim event (from Dashboard)
 */
export const logRewardClaim = async (user: string, amount: string, txHash: string) => {
    try {
        // 1. Log withdrawal
        await addDoc(collection(db, 'withdrawals'), {
            user,
            amount,
            type: 'claim_rewards',
            txHash,
            timestamp: serverTimestamp()
        });

        // 2. Update user stats
        const userRef = doc(db, 'users', user);
        await setDoc(userRef, {
            address: user,
            totalRewardsClaimed: increment(parseFloat(amount)),
            lastActive: serverTimestamp()
        }, { merge: true });

        console.log("Reward claim logged to Firebase");
    } catch (error) {
        console.error("Error logging reward claim:", error);
    }
};

// --- Admin Read Functions ---

export const getAdminEggHistory = async () => {
    try {
        const q = query(collection(db, 'egg_mints'), orderBy('timestamp', 'desc'));
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({
            ...doc.data(),
            // Convert timestamp to something serializable or use as is if component handles it
            blockNumber: 0 // Legacy field compatibility
        })) as any[];
    } catch (error) {
        console.error("Error fetching admin egg history:", error);
        return [];
    }
};

export const getAdminStakingStats = async () => {
    try {
        // Get all active stakes
        const q = query(collection(db, 'stakes'), where('status', '==', 'active'));
        const querySnapshot = await getDocs(q);

        let totalStaked = 0;
        const totalStakedByPeriod = { 3: 0, 6: 0, 12: 0 };
        let activeStakesCount = 0;

        querySnapshot.forEach((doc) => {
            const data = doc.data() as StakeLog;
            const amount = parseFloat(data.amount);

            totalStaked += amount;
            activeStakesCount++;

            if (data.lockMonths === 3 || data.lockMonths === 6 || data.lockMonths === 12) {
                totalStakedByPeriod[data.lockMonths] += amount;
            }
        });

        return {
            totalStaked,
            totalStakedByPeriod,
            activeStakesCount
        };
    } catch (error) {
        console.error("Error fetching admin staking stats:", error);
        return { totalStaked: 0, totalStakedByPeriod: { 3: 0, 6: 0, 12: 0 }, activeStakesCount: 0 };
    }
};

// --- User Management Functions (Admin) ---

export interface UserData {
    uid: string;
    username: string;
    address?: string; // Wallet address
    totalMinted: number;
    totalStaked: number;
    activeStakes: number;
    totalRewardsClaimed: number;
    lastActive?: any;
    isBanned?: boolean;
    createdAt?: any;
}

export const getAllUsers = async (): Promise<UserData[]> => {
    try {
        const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({
            uid: doc.id,
            ...doc.data()
        })) as UserData[];
    } catch (error) {
        console.error("Error fetching all users:", error);
        return [];
    }
};

export const toggleUserBan = async (uid: string, isBanned: boolean) => {
    try {
        const userRef = doc(db, 'users', uid);
        await updateDoc(userRef, {
            isBanned: isBanned
        });
        console.log(`User ${uid} ban status updated to ${isBanned}`);
    } catch (error) {
        console.error("Error toggling user ban:", error);
        throw error;
    }
};

export const checkWalletBan = async (address: string): Promise<boolean> => {
    try {
        // Query users collection for this address AND isBanned == true
        const q = query(
            collection(db, 'users'),
            where('address', '==', address),
            where('isBanned', '==', true)
        );
        const querySnapshot = await getDocs(q);
        return !querySnapshot.empty;
    } catch (error) {
        console.error("Error checking wallet ban:", error);
        return false;
    }
};
