import { auth, db } from './firebase';
import {
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    updateProfile
} from 'firebase/auth';
import {
    doc,
    getDoc,
    setDoc,
    updateDoc,
    serverTimestamp,
    collection,
    query,
    where,
    getDocs
} from 'firebase/firestore';

const EMAIL_DOMAIN = "@nexus.farm";

export const registerUser = async (username: string, password: string) => {
    // 1. Check if username is taken
    const usernameRef = doc(db, "usernames", username.toLowerCase());
    const usernameSnap = await getDoc(usernameRef);

    if (usernameSnap.exists()) {
        throw new Error("Nome de usuário já está em uso.");
    }

    // 2. Create Auth User (using fake email)
    const email = `${username.toLowerCase()}${EMAIL_DOMAIN}`;
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // 3. Update Profile Display Name
    await updateProfile(user, { displayName: username });

    // 4. Save User Data in Firestore
    await setDoc(doc(db, "users", user.uid), {
        username: username,
        usernameLower: username.toLowerCase(),
        createdAt: serverTimestamp(),
        totalMinted: 0,
        totalStaked: 0,
        activeStakes: 0,
        totalRewardsClaimed: 0
    });

    // 5. Reserve Username
    await setDoc(usernameRef, { uid: user.uid });

    return user;
};

export const loginUser = async (username: string, password: string) => {
    const email = `${username.toLowerCase()}${EMAIL_DOMAIN}`;
    try {
        // 1. Authenticate
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;

        // 2. Check if banned
        const userDoc = await getDoc(doc(db, "users", user.uid));
        if (userDoc.exists() && userDoc.data().isBanned) {
            await signOut(auth);
            throw new Error("Esta conta foi banida pelo administrador.");
        }

        return user;
    } catch (error: any) {
        if (error.code === 'auth/invalid-credential' || error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password') {
            throw new Error("Usuário ou senha incorretos.");
        }
        throw error;
    }
};

export const logoutUser = async () => {
    await signOut(auth);
};

export const checkWalletBan = async (address: string): Promise<boolean> => {
    try {
        const q = query(
            collection(db, 'users'),
            where('address', '==', address),
            where('isBanned', '==', true)
        );
        const querySnapshot = await getDocs(q);
        return !querySnapshot.empty;
    } catch (error) {
        console.error("Error checking wallet ban:", error);
        return false;
    }
};

export const linkWalletToUser = async (uid: string, walletAddress: string) => {
    // 1. Check if wallet is banned
    const isBanned = await checkWalletBan(walletAddress);
    if (isBanned) {
        throw new Error("Este endereço de carteira está com restrição na plataforma por violar regras que estava no termos de uso");
    }

    const userRef = doc(db, "users", uid);
    const userSnap = await getDoc(userRef);

    if (userSnap.exists()) {
        const userData = userSnap.data();
        const currentWallet = userData.address;
        const lastUpdated = userData.walletLastUpdated;

        // If trying to change wallet
        if (currentWallet && currentWallet.toLowerCase() !== walletAddress.toLowerCase()) {
            if (lastUpdated) {
                const lastDate = lastUpdated.toDate();
                const now = new Date();
                const diffTime = Math.abs(now.getTime() - lastDate.getTime());
                const daysPassed = diffTime / (1000 * 60 * 60 * 24);

                if (daysPassed < 7) {
                    const daysRemaining = Math.ceil(7 - daysPassed);
                    throw new Error(`Sua carteira está vinculada. Você só pode alterá-la em ${daysRemaining} dias.`);
                }
            }
        }

        // If it's the SAME wallet, we don't need to do anything or reset the timer
        if (currentWallet && currentWallet.toLowerCase() === walletAddress.toLowerCase()) {
            return;
        }
    }

    // Update
    await updateDoc(userRef, {
        address: walletAddress,
        walletLastUpdated: serverTimestamp()
    });
};
