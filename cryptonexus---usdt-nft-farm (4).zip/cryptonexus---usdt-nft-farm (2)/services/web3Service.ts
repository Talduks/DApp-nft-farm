import { NFT } from '../types';
import { MOCK_NFTS_DB } from '../constants';

/**
 * SERVIÇO DE SIMULAÇÃO WEB3
 * 
 * Em produção, este arquivo usaria 'ethers' ou 'viem' para:
 * 1. Chamar window.ethereum.request({ method: 'eth_requestAccounts' })
 * 2. Instanciar o contrato: new ethers.Contract(address, abi, signer)
 * 3. Chamar métodos do contrato: await contract.stake([nftIds])
 */

export const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

class Web3Service {
  
  // Simula conexão com MetaMask
  async connectWallet(): Promise<{ address: string, balance: number, nfts: NFT[] }> {
    await delay(1200); // Fake network delay
    
    // Retorna dados iniciais simulados do usuário
    return {
      address: "0x71C...9A23",
      balance: 1250.50, // Saldo inicial USDT
      // Simula que o usuário tem alguns NFTs na carteira, mas não todos
      nfts: JSON.parse(JSON.stringify(MOCK_NFTS_DB)) // Deep copy
    };
  }

  // Simula transação de Staking (Assinatura + Gás)
  async stakeNFTs(nftIds: string[]): Promise<boolean> {
    await delay(2000); // Tempo de confirmação do bloco
    return true; // Sucesso
  }

  // Simula retirada do Staking
  async unstakeNFTs(nftIds: string[]): Promise<boolean> {
    await delay(2000);
    return true;
  }

  // Simula o Claim de recompensas
  async claimRewards(amount: number): Promise<boolean> {
    await delay(1500);
    return true;
  }
}

export const web3Service = new Web3Service();