import { NFT, Rarity } from './types';

export const MOCK_WALLET_ADDRESS = "0x71C...9A23";

// Dados simulados de NFTs que estariam disponíveis na OpenSea
export const MOCK_NFTS_DB: NFT[] = [
  {
    id: "101",
    name: "Cyber Soldier #042",
    collectionName: "Nexus Vanguard",
    image: "https://picsum.photos/400/400?random=1",
    rarity: Rarity.COMMON,
    farmRate: 0.0005, // Aprox $43 / dia
    price: 150,
    isStaked: false
  },
  {
    id: "102",
    name: "Neon Drifter #881",
    collectionName: "Nexus Vanguard",
    image: "https://picsum.photos/400/400?random=2",
    rarity: Rarity.COMMON,
    farmRate: 0.0005,
    price: 150,
    isStaked: false
  },
  {
    id: "205",
    name: "Plasma Titan #007",
    collectionName: "Nexus Vanguard",
    image: "https://picsum.photos/400/400?random=3",
    rarity: Rarity.RARE,
    farmRate: 0.0025, // Aprox $216 / dia
    price: 600,
    isStaked: false
  },
  {
    id: "999",
    name: "Ether Goddess #001",
    collectionName: "Nexus Vanguard",
    image: "https://picsum.photos/400/400?random=4",
    rarity: Rarity.LEGENDARY,
    farmRate: 0.015, // Aprox $1296 / dia (Alto risco/retorno)
    price: 3500,
    isStaked: false
  }
];

export const APP_CONSTANTS = {
  TOKEN_SYMBOL: 'USDT',
  CONTRACT_ADDRESS: '0x1234...abcd',
  NETWORK_NAME: 'Polygon PoS',
};